"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const openai_1 = __importDefault(require("openai"));
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
// --- Schema for the first AI call (Initial Analysis) ---
const initialAnalysisJsonSchema = {
    type: "object",
    properties: {
        summary: {
            type: "string",
            description: "A concise overall summary of the lease agreement, highlighting its main purpose and any immediate standout observations."
        },
        overallSeverity: {
            type: "string",
            description: "An overall risk assessment for the lease, categorized as 'High', 'Medium', or 'Low'. This should be based on the number and severity of identified issues.",
            enum: ["High", "Medium", "Low"]
        },
        clauses: {
            type: "array",
            description: "An array of important clauses extracted from the lease document.",
            items: {
                type: "object",
                properties: {
                    title: {
                        type: "string",
                        description: "A clear, concise title for the clause (e.g., 'Rent Payment Terms', 'Subletting Restrictions', 'Maintenance Responsibilities')."
                    },
                    text: {
                        type: "string",
                        description: "The verbatim text of the clause as it appears in the lease document."
                    },
                    issues: {
                        type: "array",
                        description: "A list of potential issues, concerns, or points of attention identified within this specific clause.",
                        items: {
                            type: "object",
                            properties: {
                                description: {
                                    type: "string",
                                    description: "A clear description of the potential issue or concern."
                                },
                                severity: {
                                    type: "string",
                                    description: "The severity of this specific issue, categorized as 'High', 'Medium', or 'Low'.",
                                    enum: ["High", "Medium", "Low"]
                                },
                                recommendation: {
                                    type: "string",
                                    description: "A practical recommendation or action the user might consider regarding this issue (e.g., 'Seek clarification from landlord', 'Consult a legal professional', 'Be aware of this implication')."
                                }
                            },
                            required: ["description", "severity", "recommendation"]
                        }
                    }
                },
                required: ["title", "text", "issues"]
            }
        }
    },
    required: ["summary", "overallSeverity", "clauses"]
};
// --- Schema for the second AI call (Actionable Insights) ---
const actionableInsightsJsonSchema = {
    type: "object",
    properties: {
        actionableInsights: {
            type: "object",
            description: "Provides smart advice and actionable next steps for the user based on the overall analysis.",
            properties: {
                overallRecommendation: {
                    type: "string",
                    description: "A brief overall recommendation or takeaway message for the user based on the lease analysis."
                },
                nextSteps: {
                    type: "array",
                    description: "A list of 2-4 concrete, actionable next steps the user should consider.",
                    items: {
                        type: "object",
                        properties: {
                            step: { type: "string", description: "A single actionable step." },
                            importance: {
                                type: "string",
                                description: "Indicates the importance or urgency (e.g., 'High', 'Medium', 'Consider').",
                                enum: ["High", "Medium", "Consider"]
                            },
                            details: { type: "string", description: "(Optional) Further details or rationale for this step, if necessary." }
                        },
                        required: ["step", "importance"]
                    }
                }
            },
            required: ["overallRecommendation", "nextSteps"]
        }
    },
    required: ["actionableInsights"]
};
// --- Core AI Processing Function (copied and adapted from leaseAnalysisLogic.ts) ---
async function performAiLeaseAnalysisInternal(extractedText, userSelectedState, // Can be undefined if not present
openaiClient) {
    let initialAnalysisResults;
    let actionableInsightsData;
    const stateForPrompt = userSelectedState || 'general'; // Fallback if state is not provided
    // === PHASE 1: Initial Lease Analysis ===
    try {
        const systemMessageInitial = `You are a legal assistant specializing in ${stateForPrompt} lease agreements. Analyze the lease text. Respond ONLY with a valid JSON object adhering to this schema: ${JSON.stringify(initialAnalysisJsonSchema, null, 2)}`;
        const userMessageInitial = `Lease text: ${extractedText}`;
        console.log('(AI Lambda) Calling OpenAI for initial analysis...');
        const responseInitial = await openaiClient.chat.completions.create({
            model: process.env.OPENAI_MODEL || "gpt-4o", // Use environment variable for model
            messages: [{ role: "system", content: systemMessageInitial }, { role: "user", content: userMessageInitial }],
            response_format: { type: "json_object" },
            temperature: 0.2,
        });
        const rawContentInitial = responseInitial.choices[0]?.message?.content;
        if (!rawContentInitial)
            throw new Error('Initial analysis: No content from AI.');
        initialAnalysisResults = JSON.parse(rawContentInitial);
        console.log('(AI Lambda) Initial analysis successful.');
    }
    catch (aiError) {
        console.error('(AI Lambda) Error during initial AI analysis:', aiError);
        throw new Error(`Initial AI Analysis Failed: ${aiError instanceof Error ? aiError.message : String(aiError)}`);
    }
    // === PHASE 2: Generate Actionable Insights ===
    try {
        let contextForInsights = `Summary: ${initialAnalysisResults.summary}. Overall Severity: ${initialAnalysisResults.overallSeverity}.`;
        const highSeverityIssues = initialAnalysisResults.clauses
            .flatMap((c) => c.issues)
            .filter((i) => i.severity === 'High')
            .map((i) => i.description);
        if (highSeverityIssues.length > 0) {
            contextForInsights += ` Key high-severity issues include: ${highSeverityIssues.join('; ')}`;
        }
        const systemMessageInsights = `Based on the following lease analysis context for a ${stateForPrompt} lease, provide actionable next steps for the user. Respond ONLY with a valid JSON object adhering to this schema: ${JSON.stringify(actionableInsightsJsonSchema, null, 2)}`;
        const userMessageInsights = `Context: ${contextForInsights.substring(0, 3500)} Please provide actionable insights.`;
        console.log('(AI Lambda) Calling OpenAI for actionable insights...');
        const responseInsights = await openaiClient.chat.completions.create({
            model: process.env.OPENAI_MODEL || "gpt-4o", // Use environment variable for model
            messages: [{ role: "system", content: systemMessageInsights }, { role: "user", content: userMessageInsights }],
            response_format: { type: "json_object" },
            temperature: 0.5,
        });
        const rawContentInsights = responseInsights.choices[0]?.message?.content;
        if (!rawContentInsights)
            throw new Error('Actionable insights: No content from AI.');
        actionableInsightsData = JSON.parse(rawContentInsights);
        console.log('(AI Lambda) Actionable insights generation successful.');
    }
    catch (aiError) {
        console.error('(AI Lambda) Error during actionable insights generation:', aiError);
        const error = new Error(`Actionable Insights Generation Failed: ${aiError instanceof Error ? aiError.message : String(aiError)}`);
        error.partialResults = initialAnalysisResults; // Attach partial results
        throw error;
    }
    return { initialAnalysisResults, actionableInsightsData };
}
const DYNAMODB_TABLE = process.env.DYNAMODB_LEASE_ANALYSES_TABLE;
const OPENAI_API_KEY_SECRET_NAME = process.env.OPENAI_API_KEY_SECRET_NAME;
const AWS_REGION = process.env.AWS_REGION;
if (!DYNAMODB_TABLE) {
    throw new Error("DYNAMODB_LEASE_ANALYSES_TABLE environment variable is not set.");
}
if (!OPENAI_API_KEY_SECRET_NAME) {
    throw new Error("OPENAI_API_KEY_SECRET_NAME environment variable is not set.");
}
if (!AWS_REGION) {
    throw new Error("AWS_REGION environment variable is not set.");
}
const dynamoDBClient = new client_dynamodb_1.DynamoDBClient({ region: AWS_REGION });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDBClient);
let openaiClient;
async function initializeOpenAIClient() {
    if (openaiClient) {
        return openaiClient;
    }
    console.log(`Fetching OpenAI API key from Secrets Manager: ${OPENAI_API_KEY_SECRET_NAME}`);
    const secretsClient = new client_secrets_manager_1.SecretsManagerClient({ region: AWS_REGION });
    try {
        const command = new client_secrets_manager_1.GetSecretValueCommand({ SecretId: OPENAI_API_KEY_SECRET_NAME });
        const data = await secretsClient.send(command);
        let secretValue;
        if (data.SecretString) {
            secretValue = data.SecretString;
        }
        else if (data.SecretBinary) {
            // If SecretBinary is used, you need to decode it (e.g., base64)
            // For this example, assuming SecretString
            console.warn("OpenAI API Key secret is binary, expected string.");
            throw new Error("OpenAI API Key secret is binary, expected string.");
        }
        if (!secretValue) {
            console.error("OpenAI API Key secret string is empty.");
            throw new Error("Retrieved OpenAI API Key secret is empty.");
        }
        // Try to parse as JSON, if it fails, assume it's a plain string key
        let apiKey;
        try {
            const secretJson = JSON.parse(secretValue);
            // Adjust this if your secret is stored with a different key within the JSON
            apiKey = secretJson.OPENAI_API_KEY || secretJson.apiKey || secretJson.key;
            if (!apiKey && typeof secretJson === 'string')
                apiKey = secretJson; // if JSON is just the key string itself
            else if (!apiKey)
                apiKey = secretValue; // Fallback if key not found in JSON structure
        }
        catch (e) {
            // Not a JSON string, assume the secret IS the API key
            apiKey = secretValue;
        }
        if (!apiKey) {
            throw new Error("Unable to extract OpenAI API Key from secret.");
        }
        openaiClient = new openai_1.default({ apiKey });
        console.log("OpenAI client initialized successfully.");
        return openaiClient;
    }
    catch (err) {
        console.error("Error fetching/parsing OpenAI API key from Secrets Manager:", err);
        throw new Error(`Failed to retrieve/parse OpenAI API Key: ${err instanceof Error ? err.message : String(err)}`);
    }
}
const handler = async (event, context) => {
    console.log('AI Lease Processing Lambda invoked. Event:', JSON.stringify(event, null, 2));
    try {
        openaiClient = await initializeOpenAIClient();
    }
    catch (initError) {
        console.error("Failed to initialize OpenAI client:", initError);
        throw initError;
    }
    for (const record of event.Records) {
        let analysisId;
        let sqsMessageBody; // To store the parsed body for wider use
        try {
            sqsMessageBody = JSON.parse(record.body);
            analysisId = sqsMessageBody.analysisId;
            const userUploadedFileName = sqsMessageBody.originalFileName || sqsMessageBody.userUploadedFileName; // Use originalFileName from SQS
            if (!analysisId) {
                console.error("analysisId is missing in SQS message body:", sqsMessageBody);
                continue;
            }
            // Ensure critical data from SQS message is present
            if (!sqsMessageBody.extractedText) {
                console.error(`Extracted text is missing in SQS message body for analysisId: ${analysisId}`);
                // Update DDB with error and continue
                await updateDynamoDBOnError(analysisId, "AI_PROCESSING_FAILED", "Missing extractedText in SQS message");
                continue;
            }
            if (!sqsMessageBody.userSelectedState) {
                console.warn(`userSelectedState is missing in SQS message body for analysisId: ${analysisId}. AI will use a general prompt.`);
                // AI function has a fallback, so this is not fatal, but good to log.
            }
            console.log(`Processing analysisId: ${analysisId} for file: ${userUploadedFileName || 'N/A'}`);
            // 1. Data directly from SQS message body
            const extractedText = sqsMessageBody.extractedText;
            const userSelectedState = sqsMessageBody.userSelectedState;
            // s3Key, s3Bucket are also available in sqsMessageBody if needed later
            // 2. Update status to AI_PROCESSING_IN_PROGRESS
            console.log(`Updating status to AI_PROCESSING_IN_PROGRESS for ${analysisId}`);
            const updateInProgressParams = {
                TableName: DYNAMODB_TABLE,
                Key: { analysisId },
                UpdateExpression: "set #status = :status, #lastUpdatedTimestamp = :timestamp",
                ExpressionAttributeNames: { "#status": "status", "#lastUpdatedTimestamp": "lastUpdatedTimestamp" },
                ExpressionAttributeValues: {
                    ":status": "AI_PROCESSING_IN_PROGRESS",
                    ":timestamp": new Date().toISOString(),
                },
            };
            await docClient.send(new lib_dynamodb_1.UpdateCommand(updateInProgressParams));
            let finalResults = null;
            let finalStatus = '';
            let errorDetails = null;
            try {
                // 3. Perform AI Analysis using data from SQS message
                console.log(`Performing AI analysis for ${analysisId} using text of length ${extractedText.length} for state: ${userSelectedState || 'general'}`);
                const { initialAnalysisResults, actionableInsightsData } = await performAiLeaseAnalysisInternal(extractedText, // From SQS message
                userSelectedState, // From SQS message
                openaiClient);
                finalResults = { ...initialAnalysisResults, ...actionableInsightsData };
                finalStatus = 'ANALYSIS_COMPLETE';
                console.log(`AI analysis successful for ${analysisId}`);
            }
            catch (aiError) {
                console.error(`Error during AI processing for ${analysisId}:`, aiError);
                finalStatus = 'AI_PROCESSING_FAILED';
                errorDetails = aiError.message || "Unknown AI processing error.";
                if (aiError.partialResults) {
                    // If actionable insights failed, but initial analysis succeeded
                    finalResults = { ...aiError.partialResults, actionableInsights: { overallRecommendation: "", nextSteps: [] } };
                    finalStatus = 'PARTIAL_ANALYSIS_INSIGHTS_FAILED';
                    errorDetails = `Insights: ${errorDetails}`;
                    console.log(`Partial results saved for ${analysisId} due to insights failure.`);
                }
            }
            // 4. Update DynamoDB with final results/status
            console.log(`Updating status to ${finalStatus} for ${analysisId}`);
            const updateFinalParams = {
                TableName: DYNAMODB_TABLE,
                Key: { analysisId },
                UpdateExpression: "set #status = :status, #analysisResults = :analysisResults, #lastUpdatedTimestamp = :timestamp",
                ExpressionAttributeNames: {
                    "#status": "status",
                    "#analysisResults": "analysisResults",
                    "#lastUpdatedTimestamp": "lastUpdatedTimestamp",
                },
                ExpressionAttributeValues: {
                    ":status": finalStatus,
                    ":analysisResults": finalResults, // Store the combined results
                    ":timestamp": new Date().toISOString(),
                },
            };
            if (errorDetails) {
                updateFinalParams.UpdateExpression += ", #errorDetails = :errorDetails";
                updateFinalParams.ExpressionAttributeNames["#errorDetails"] = "errorDetails";
                updateFinalParams.ExpressionAttributeValues[":errorDetails"] = errorDetails;
            }
            await docClient.send(new lib_dynamodb_1.UpdateCommand(updateFinalParams));
            console.log(`Successfully processed and updated ${analysisId}. Status: ${finalStatus}`);
        }
        catch (error) {
            console.error(`Failed to process SQS record for analysisId ${analysisId || 'unknown'}:`, error);
            // If analysisId is known and error is not during final DDB update, try to update DDB with error status
            if (analysisId) {
                await updateDynamoDBOnError(analysisId, 'AI_PROCESSING_FAILED', error.message || 'Unknown error during SQS record processing');
            }
        }
    }
};
exports.handler = handler;
// Helper function to update DynamoDB on error, to avoid code duplication in catch blocks
async function updateDynamoDBOnError(analysisId, status, errorMessage) {
    console.log(`Updating DynamoDB for ${analysisId} with error status ${status} due to: ${errorMessage}`);
    try {
        const errorUpdateParams = {
            TableName: DYNAMODB_TABLE,
            Key: { analysisId },
            UpdateExpression: "set #status = :status, #errorDetails = :errorDetails, #lastUpdatedTimestamp = :timestamp",
            ExpressionAttributeNames: {
                "#status": "status",
                "#errorDetails": "errorDetails",
                "#lastUpdatedTimestamp": "lastUpdatedTimestamp"
            },
            ExpressionAttributeValues: {
                ":status": status,
                ":errorDetails": errorMessage.substring(0, 2000), // Cap error message length
                ":timestamp": new Date().toISOString(),
            },
        };
        await docClient.send(new lib_dynamodb_1.UpdateCommand(errorUpdateParams));
        console.log(`Successfully updated ${analysisId} with error status.`);
    }
    catch (dbError) {
        console.error(`Failed to update DynamoDB with error status for ${analysisId}:`, dbError);
        // Swallow this error as the main error is already logged.
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxvREFBNEI7QUFDNUIsOERBQTBEO0FBQzFELHdEQUEwRjtBQUMxRiw0RUFBOEY7QUFxQzlGLDBEQUEwRDtBQUMxRCxNQUFNLHlCQUF5QixHQUFHO0lBQ2hDLElBQUksRUFBRSxRQUFRO0lBQ2QsVUFBVSxFQUFFO1FBQ1YsT0FBTyxFQUFFO1lBQ1AsSUFBSSxFQUFFLFFBQVE7WUFDZCxXQUFXLEVBQUUsMEhBQTBIO1NBQ3hJO1FBQ0QsZUFBZSxFQUFFO1lBQ2YsSUFBSSxFQUFFLFFBQVE7WUFDZCxXQUFXLEVBQUUsNEpBQTRKO1lBQ3pLLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDO1NBQ2hDO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsSUFBSSxFQUFFLE9BQU87WUFDYixXQUFXLEVBQUUsa0VBQWtFO1lBQy9FLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxVQUFVLEVBQUU7b0JBQ1YsS0FBSyxFQUFFO3dCQUNMLElBQUksRUFBRSxRQUFRO3dCQUNkLFdBQVcsRUFBRSxnSUFBZ0k7cUJBQzlJO29CQUNELElBQUksRUFBRTt3QkFDSixJQUFJLEVBQUUsUUFBUTt3QkFDZCxXQUFXLEVBQUUsc0VBQXNFO3FCQUNwRjtvQkFDRCxNQUFNLEVBQUU7d0JBQ04sSUFBSSxFQUFFLE9BQU87d0JBQ2IsV0FBVyxFQUFFLHNHQUFzRzt3QkFDbkgsS0FBSyxFQUFFOzRCQUNMLElBQUksRUFBRSxRQUFROzRCQUNkLFVBQVUsRUFBRTtnQ0FDVixXQUFXLEVBQUU7b0NBQ1gsSUFBSSxFQUFFLFFBQVE7b0NBQ2QsV0FBVyxFQUFFLHdEQUF3RDtpQ0FDdEU7Z0NBQ0QsUUFBUSxFQUFFO29DQUNSLElBQUksRUFBRSxRQUFRO29DQUNkLFdBQVcsRUFBRSxpRkFBaUY7b0NBQzlGLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDO2lDQUNoQztnQ0FDRCxjQUFjLEVBQUU7b0NBQ2QsSUFBSSxFQUFFLFFBQVE7b0NBQ2QsV0FBVyxFQUFFLCtMQUErTDtpQ0FDN007NkJBQ0Y7NEJBQ0QsUUFBUSxFQUFFLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQzt5QkFDeEQ7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsUUFBUSxFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUM7YUFDdEM7U0FDRjtLQUNGO0lBQ0QsUUFBUSxFQUFFLENBQUMsU0FBUyxFQUFFLGlCQUFpQixFQUFFLFNBQVMsQ0FBQztDQUNwRCxDQUFDO0FBRUYsOERBQThEO0FBQzlELE1BQU0sNEJBQTRCLEdBQUc7SUFDbkMsSUFBSSxFQUFFLFFBQVE7SUFDZCxVQUFVLEVBQUU7UUFDVixrQkFBa0IsRUFBRTtZQUNsQixJQUFJLEVBQUUsUUFBUTtZQUNkLFdBQVcsRUFBRSw2RkFBNkY7WUFDMUcsVUFBVSxFQUFFO2dCQUNWLHFCQUFxQixFQUFFO29CQUNyQixJQUFJLEVBQUUsUUFBUTtvQkFDZCxXQUFXLEVBQUUsOEZBQThGO2lCQUM1RztnQkFDRCxTQUFTLEVBQUU7b0JBQ1QsSUFBSSxFQUFFLE9BQU87b0JBQ2IsV0FBVyxFQUFFLHlFQUF5RTtvQkFDdEYsS0FBSyxFQUFFO3dCQUNMLElBQUksRUFBRSxRQUFRO3dCQUNkLFVBQVUsRUFBRTs0QkFDVixJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSwyQkFBMkIsRUFBRTs0QkFDbEUsVUFBVSxFQUFFO2dDQUNWLElBQUksRUFBRSxRQUFRO2dDQUNkLFdBQVcsRUFBRSwyRUFBMkU7Z0NBQ3hGLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsVUFBVSxDQUFDOzZCQUNyQzs0QkFDRCxPQUFPLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxzRUFBc0UsRUFBRTt5QkFDakg7d0JBQ0QsUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQztxQkFDakM7aUJBQ0Y7YUFDRjtZQUNELFFBQVEsRUFBRSxDQUFDLHVCQUF1QixFQUFFLFdBQVcsQ0FBQztTQUNqRDtLQUNGO0lBQ0QsUUFBUSxFQUFFLENBQUMsb0JBQW9CLENBQUM7Q0FDakMsQ0FBQztBQUVGLHNGQUFzRjtBQUN0RixLQUFLLFVBQVUsOEJBQThCLENBQzNDLGFBQXFCLEVBQ3JCLGlCQUFxQyxFQUFFLGtDQUFrQztBQUN6RSxZQUFvQjtJQUVwQixJQUFJLHNCQUE4QyxDQUFDO0lBQ25ELElBQUksc0JBQThDLENBQUM7SUFDbkQsTUFBTSxjQUFjLEdBQUcsaUJBQWlCLElBQUksU0FBUyxDQUFDLENBQUMsb0NBQW9DO0lBRTNGLDBDQUEwQztJQUMxQyxJQUFJLENBQUM7UUFDSCxNQUFNLG9CQUFvQixHQUFHLDZDQUE2QyxjQUFjLDZHQUE2RyxJQUFJLENBQUMsU0FBUyxDQUFDLHlCQUF5QixFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzFQLE1BQU0sa0JBQWtCLEdBQUcsZUFBZSxhQUFhLEVBQUUsQ0FBQztRQUUxRCxPQUFPLENBQUMsR0FBRyxDQUFDLG9EQUFvRCxDQUFDLENBQUM7UUFDbEUsTUFBTSxlQUFlLEdBQUcsTUFBTSxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7WUFDakUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLFFBQVEsRUFBRSxxQ0FBcUM7WUFDbEYsUUFBUSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsQ0FBQztZQUM1RyxlQUFlLEVBQUUsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQ3hDLFdBQVcsRUFBRSxHQUFHO1NBQ2pCLENBQUMsQ0FBQztRQUVILE1BQU0saUJBQWlCLEdBQUcsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxpQkFBaUI7WUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7UUFDakYsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBMkIsQ0FBQztRQUNqRixPQUFPLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUM7SUFFMUQsQ0FBQztJQUFDLE9BQU8sT0FBTyxFQUFFLENBQUM7UUFDakIsT0FBTyxDQUFDLEtBQUssQ0FBQywrQ0FBK0MsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN4RSxNQUFNLElBQUksS0FBSyxDQUFDLCtCQUErQixPQUFPLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ2pILENBQUM7SUFFRCxnREFBZ0Q7SUFDaEQsSUFBSSxDQUFDO1FBQ0gsSUFBSSxrQkFBa0IsR0FBRyxZQUFZLHNCQUFzQixDQUFDLE9BQU8sdUJBQXVCLHNCQUFzQixDQUFDLGVBQWUsR0FBRyxDQUFDO1FBQ3BJLE1BQU0sa0JBQWtCLEdBQUcsc0JBQXNCLENBQUMsT0FBTzthQUN0RCxPQUFPLENBQUMsQ0FBQyxDQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7YUFDaEMsTUFBTSxDQUFDLENBQUMsQ0FBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLE1BQU0sQ0FBQzthQUMzQyxHQUFHLENBQUMsQ0FBQyxDQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNwQyxJQUFJLGtCQUFrQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNsQyxrQkFBa0IsSUFBSSxzQ0FBc0Msa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDOUYsQ0FBQztRQUVELE1BQU0scUJBQXFCLEdBQUcsdURBQXVELGNBQWMsc0hBQXNILElBQUksQ0FBQyxTQUFTLENBQUMsNEJBQTRCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDalIsTUFBTSxtQkFBbUIsR0FBRyxZQUFZLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLHNDQUFzQyxDQUFDO1FBRXBILE9BQU8sQ0FBQyxHQUFHLENBQUMsdURBQXVELENBQUMsQ0FBQztRQUNyRSxNQUFNLGdCQUFnQixHQUFHLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO1lBQ2xFLEtBQUssRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksSUFBSSxRQUFRLEVBQUUscUNBQXFDO1lBQ2xGLFFBQVEsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLG1CQUFtQixFQUFFLENBQUM7WUFDOUcsZUFBZSxFQUFFLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUN4QyxXQUFXLEVBQUUsR0FBRztTQUNqQixDQUFDLENBQUM7UUFFSCxNQUFNLGtCQUFrQixHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDO1FBQ3pFLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUM7UUFDckYsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBMkIsQ0FBQztRQUNsRixPQUFPLENBQUMsR0FBRyxDQUFDLHdEQUF3RCxDQUFDLENBQUM7SUFFeEUsQ0FBQztJQUFDLE9BQU8sT0FBTyxFQUFFLENBQUM7UUFDakIsT0FBTyxDQUFDLEtBQUssQ0FBQywwREFBMEQsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNuRixNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsT0FBTyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNqSSxLQUFhLENBQUMsY0FBYyxHQUFHLHNCQUFzQixDQUFDLENBQUMseUJBQXlCO1FBQ2pGLE1BQU0sS0FBSyxDQUFDO0lBQ2QsQ0FBQztJQUVELE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxzQkFBc0IsRUFBRSxDQUFDO0FBQzVELENBQUM7QUFFRCxNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDO0FBQ2pFLE1BQU0sMEJBQTBCLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQztBQUMxRSxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztBQUUxQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDcEIsTUFBTSxJQUFJLEtBQUssQ0FBQyxnRUFBZ0UsQ0FBQyxDQUFDO0FBQ3BGLENBQUM7QUFDRCxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztJQUNoQyxNQUFNLElBQUksS0FBSyxDQUFDLDZEQUE2RCxDQUFDLENBQUM7QUFDakYsQ0FBQztBQUNELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNoQixNQUFNLElBQUksS0FBSyxDQUFDLDZDQUE2QyxDQUFDLENBQUM7QUFDakUsQ0FBQztBQUVELE1BQU0sY0FBYyxHQUFHLElBQUksZ0NBQWMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDO0FBQ2xFLE1BQU0sU0FBUyxHQUFHLHFDQUFzQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUM5RCxJQUFJLFlBQW9CLENBQUM7QUFFekIsS0FBSyxVQUFVLHNCQUFzQjtJQUNuQyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ2pCLE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLGlEQUFpRCwwQkFBMEIsRUFBRSxDQUFDLENBQUM7SUFDM0YsTUFBTSxhQUFhLEdBQUcsSUFBSSw2Q0FBb0IsQ0FBQyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZFLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLElBQUksOENBQXFCLENBQUMsRUFBRSxRQUFRLEVBQUUsMEJBQTBCLEVBQUUsQ0FBQyxDQUFDO1FBQ3BGLE1BQU0sSUFBSSxHQUFHLE1BQU0sYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQyxJQUFJLFdBQStCLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDdEIsV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDbEMsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQzdCLGdFQUFnRTtZQUNoRSwwQ0FBMEM7WUFDMUMsT0FBTyxDQUFDLElBQUksQ0FBQyxtREFBbUQsQ0FBQyxDQUFDO1lBQ2xFLE1BQU0sSUFBSSxLQUFLLENBQUMsbURBQW1ELENBQUMsQ0FBQztRQUN2RSxDQUFDO1FBRUQsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ3hELE1BQU0sSUFBSSxLQUFLLENBQUMsMkNBQTJDLENBQUMsQ0FBQztRQUNqRSxDQUFDO1FBRUQsb0VBQW9FO1FBQ3BFLElBQUksTUFBTSxDQUFDO1FBQ1gsSUFBSSxDQUFDO1lBQ0QsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMzQyw0RUFBNEU7WUFDNUUsTUFBTSxHQUFHLFVBQVUsQ0FBQyxjQUFjLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDO1lBQzFFLElBQUksQ0FBQyxNQUFNLElBQUksT0FBTyxVQUFVLEtBQUssUUFBUTtnQkFBRSxNQUFNLEdBQUcsVUFBVSxDQUFDLENBQUMsd0NBQXdDO2lCQUN2RyxJQUFJLENBQUMsTUFBTTtnQkFBRSxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsOENBQThDO1FBRTFGLENBQUM7UUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ1Qsc0RBQXNEO1lBQ3RELE1BQU0sR0FBRyxXQUFXLENBQUM7UUFDekIsQ0FBQztRQUVELElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNWLE1BQU0sSUFBSSxLQUFLLENBQUMsK0NBQStDLENBQUMsQ0FBQztRQUNyRSxDQUFDO1FBRUQsWUFBWSxHQUFHLElBQUksZ0JBQU0sQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sWUFBWSxDQUFDO0lBRXRCLENBQUM7SUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2IsT0FBTyxDQUFDLEtBQUssQ0FBQyw2REFBNkQsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNsRixNQUFNLElBQUksS0FBSyxDQUFDLDRDQUE0QyxHQUFHLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ2xILENBQUM7QUFDSCxDQUFDO0FBRU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQVUsRUFBRSxPQUFZLEVBQWlCLEVBQUU7SUFDdkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUUxRixJQUFJLENBQUM7UUFDSCxZQUFZLEdBQUcsTUFBTSxzQkFBc0IsRUFBRSxDQUFDO0lBQ2hELENBQUM7SUFBQyxPQUFPLFNBQVMsRUFBRSxDQUFDO1FBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDaEUsTUFBTSxTQUFTLENBQUM7SUFDbEIsQ0FBQztJQUVELEtBQUssTUFBTSxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ25DLElBQUksVUFBOEIsQ0FBQztRQUNuQyxJQUFJLGNBQW1CLENBQUMsQ0FBQyx5Q0FBeUM7UUFFbEUsSUFBSSxDQUFDO1lBQ0gsY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3pDLFVBQVUsR0FBRyxjQUFjLENBQUMsVUFBVSxDQUFDO1lBQ3ZDLE1BQU0sb0JBQW9CLEdBQUcsY0FBYyxDQUFDLGdCQUFnQixJQUFJLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLGdDQUFnQztZQUVySSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2hCLE9BQU8sQ0FBQyxLQUFLLENBQUMsNENBQTRDLEVBQUUsY0FBYyxDQUFDLENBQUM7Z0JBQzVFLFNBQVM7WUFDWCxDQUFDO1lBQ0QsbURBQW1EO1lBQ25ELElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2xDLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUVBQWlFLFVBQVUsRUFBRSxDQUFDLENBQUM7Z0JBQzdGLHFDQUFxQztnQkFDckMsTUFBTSxxQkFBcUIsQ0FBQyxVQUFVLEVBQUUsc0JBQXNCLEVBQUUsc0NBQXNDLENBQUMsQ0FBQztnQkFDeEcsU0FBUztZQUNYLENBQUM7WUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMsb0VBQW9FLFVBQVUsaUNBQWlDLENBQUMsQ0FBQztnQkFDOUgscUVBQXFFO1lBQ3ZFLENBQUM7WUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixVQUFVLGNBQWMsb0JBQW9CLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQztZQUUvRix5Q0FBeUM7WUFDekMsTUFBTSxhQUFhLEdBQUcsY0FBYyxDQUFDLGFBQXVCLENBQUM7WUFDN0QsTUFBTSxpQkFBaUIsR0FBRyxjQUFjLENBQUMsaUJBQXVDLENBQUM7WUFDakYsdUVBQXVFO1lBRXZFLGdEQUFnRDtZQUNoRCxPQUFPLENBQUMsR0FBRyxDQUFDLG9EQUFvRCxVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBQzlFLE1BQU0sc0JBQXNCLEdBQUc7Z0JBQzdCLFNBQVMsRUFBRSxjQUFlO2dCQUMxQixHQUFHLEVBQUUsRUFBRSxVQUFVLEVBQUU7Z0JBQ25CLGdCQUFnQixFQUFFLDJEQUEyRDtnQkFDN0Usd0JBQXdCLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLHVCQUF1QixFQUFFLHNCQUFzQixFQUFFO2dCQUNsRyx5QkFBeUIsRUFBRTtvQkFDekIsU0FBUyxFQUFFLDJCQUEyQjtvQkFDdEMsWUFBWSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2lCQUN2QzthQUNGLENBQUM7WUFDRixNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSw0QkFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQztZQUVoRSxJQUFJLFlBQVksR0FBNkIsSUFBSSxDQUFDO1lBQ2xELElBQUksV0FBVyxHQUFXLEVBQUUsQ0FBQztZQUM3QixJQUFJLFlBQVksR0FBa0IsSUFBSSxDQUFDO1lBRXZDLElBQUksQ0FBQztnQkFDSCxxREFBcUQ7Z0JBQ3JELE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLFVBQVUseUJBQXlCLGFBQWEsQ0FBQyxNQUFNLGVBQWUsaUJBQWlCLElBQUksU0FBUyxFQUFFLENBQUMsQ0FBQztnQkFDbEosTUFBTSxFQUFFLHNCQUFzQixFQUFFLHNCQUFzQixFQUFFLEdBQUcsTUFBTSw4QkFBOEIsQ0FDN0YsYUFBYSxFQUFXLG1CQUFtQjtnQkFDM0MsaUJBQWlCLEVBQU8sbUJBQW1CO2dCQUMzQyxZQUFZLENBQ2IsQ0FBQztnQkFDRixZQUFZLEdBQUcsRUFBRSxHQUFHLHNCQUFzQixFQUFFLEdBQUcsc0JBQXNCLEVBQUUsQ0FBQztnQkFDeEUsV0FBVyxHQUFHLG1CQUFtQixDQUFDO2dCQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBRTFELENBQUM7WUFBQyxPQUFPLE9BQVksRUFBRSxDQUFDO2dCQUN0QixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxVQUFVLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDeEUsV0FBVyxHQUFHLHNCQUFzQixDQUFDO2dCQUNyQyxZQUFZLEdBQUcsT0FBTyxDQUFDLE9BQU8sSUFBSSw4QkFBOEIsQ0FBQztnQkFDakUsSUFBSSxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3pCLGdFQUFnRTtvQkFDaEUsWUFBWSxHQUFHLEVBQUUsR0FBSSxPQUFPLENBQUMsY0FBeUMsRUFBRSxrQkFBa0IsRUFBRSxFQUFFLHFCQUFxQixFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFDLEVBQUUsQ0FBQztvQkFDMUksV0FBVyxHQUFHLGtDQUFrQyxDQUFDO29CQUNqRCxZQUFZLEdBQUcsYUFBYSxZQUFZLEVBQUUsQ0FBQztvQkFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsVUFBVSwyQkFBMkIsQ0FBQyxDQUFDO2dCQUNwRixDQUFDO1lBQ0gsQ0FBQztZQUVELCtDQUErQztZQUMvQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixXQUFXLFFBQVEsVUFBVSxFQUFFLENBQUMsQ0FBQztZQUNuRSxNQUFNLGlCQUFpQixHQUFRO2dCQUM3QixTQUFTLEVBQUUsY0FBZTtnQkFDMUIsR0FBRyxFQUFFLEVBQUUsVUFBVSxFQUFFO2dCQUNuQixnQkFBZ0IsRUFBRSxnR0FBZ0c7Z0JBQ2xILHdCQUF3QixFQUFFO29CQUN4QixTQUFTLEVBQUUsUUFBUTtvQkFDbkIsa0JBQWtCLEVBQUUsaUJBQWlCO29CQUNyQyx1QkFBdUIsRUFBRSxzQkFBc0I7aUJBQ2hEO2dCQUNELHlCQUF5QixFQUFFO29CQUN6QixTQUFTLEVBQUUsV0FBVztvQkFDdEIsa0JBQWtCLEVBQUUsWUFBWSxFQUFFLDZCQUE2QjtvQkFDL0QsWUFBWSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2lCQUN2QzthQUNGLENBQUM7WUFDRixJQUFJLFlBQVksRUFBRSxDQUFDO2dCQUNqQixpQkFBaUIsQ0FBQyxnQkFBZ0IsSUFBSSxpQ0FBaUMsQ0FBQztnQkFDeEUsaUJBQWlCLENBQUMsd0JBQXdCLENBQUMsZUFBZSxDQUFDLEdBQUcsY0FBYyxDQUFDO2dCQUM3RSxpQkFBaUIsQ0FBQyx5QkFBeUIsQ0FBQyxlQUFlLENBQUMsR0FBRyxZQUFZLENBQUM7WUFDOUUsQ0FBQztZQUNELE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLDRCQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO1lBQzNELE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLFVBQVUsYUFBYSxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRTFGLENBQUM7UUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0NBQStDLFVBQVUsSUFBSSxTQUFTLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNoRyx1R0FBdUc7WUFDdkcsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZixNQUFNLHFCQUFxQixDQUFDLFVBQVUsRUFBRSxzQkFBc0IsRUFBRSxLQUFLLENBQUMsT0FBTyxJQUFJLDRDQUE0QyxDQUFDLENBQUM7WUFDakksQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBdEhXLFFBQUEsT0FBTyxXQXNIbEI7QUFFRix5RkFBeUY7QUFDekYsS0FBSyxVQUFVLHFCQUFxQixDQUFDLFVBQWtCLEVBQUUsTUFBYyxFQUFFLFlBQW9CO0lBQ3pGLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLFVBQVUsc0JBQXNCLE1BQU0sWUFBWSxZQUFZLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZHLElBQUksQ0FBQztRQUNELE1BQU0saUJBQWlCLEdBQUc7WUFDdEIsU0FBUyxFQUFFLGNBQWU7WUFDMUIsR0FBRyxFQUFFLEVBQUUsVUFBVSxFQUFFO1lBQ25CLGdCQUFnQixFQUFFLDBGQUEwRjtZQUM1Ryx3QkFBd0IsRUFBRTtnQkFDdEIsU0FBUyxFQUFFLFFBQVE7Z0JBQ25CLGVBQWUsRUFBRSxjQUFjO2dCQUMvQix1QkFBdUIsRUFBRSxzQkFBc0I7YUFDbEQ7WUFDRCx5QkFBeUIsRUFBRTtnQkFDdkIsU0FBUyxFQUFFLE1BQU07Z0JBQ2pCLGVBQWUsRUFBRSxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsRUFBRSwyQkFBMkI7Z0JBQzdFLFlBQVksRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUN6QztTQUNKLENBQUM7UUFDRixNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSw0QkFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUMzRCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixVQUFVLHFCQUFxQixDQUFDLENBQUM7SUFDekUsQ0FBQztJQUFDLE9BQU8sT0FBTyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLG1EQUFtRCxVQUFVLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6RiwwREFBMEQ7SUFDOUQsQ0FBQztBQUNMLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgT3BlbkFJIGZyb20gJ29wZW5haSc7XHJcbmltcG9ydCB7IER5bmFtb0RCQ2xpZW50IH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LWR5bmFtb2RiJztcclxuaW1wb3J0IHsgRHluYW1vREJEb2N1bWVudENsaWVudCwgR2V0Q29tbWFuZCwgVXBkYXRlQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2xpYi1keW5hbW9kYic7XHJcbmltcG9ydCB7IFNlY3JldHNNYW5hZ2VyQ2xpZW50LCBHZXRTZWNyZXRWYWx1ZUNvbW1hbmQgfSBmcm9tIFwiQGF3cy1zZGsvY2xpZW50LXNlY3JldHMtbWFuYWdlclwiO1xyXG5cclxuLy8gLS0tIFR5cGVTY3JpcHQgSW50ZXJmYWNlcyBmb3IgQUkgU2NoZW1hcyAoY29waWVkIGZyb20gbGVhc2VBbmFseXNpc0xvZ2ljLnRzKSAtLS1cclxuZXhwb3J0IGludGVyZmFjZSBJc3N1ZSB7XHJcbiAgZGVzY3JpcHRpb246IHN0cmluZztcclxuICBzZXZlcml0eTogXCJIaWdoXCIgfCBcIk1lZGl1bVwiIHwgXCJMb3dcIjtcclxuICByZWNvbW1lbmRhdGlvbjogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENsYXVzZSB7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICB0ZXh0OiBzdHJpbmc7XHJcbiAgaXNzdWVzOiBJc3N1ZVtdO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEluaXRpYWxBbmFseXNpc1Jlc3VsdHMge1xyXG4gIHN1bW1hcnk6IHN0cmluZztcclxuICBvdmVyYWxsU2V2ZXJpdHk6IFwiSGlnaFwiIHwgXCJNZWRpdW1cIiB8IFwiTG93XCI7XHJcbiAgY2xhdXNlczogQ2xhdXNlW107XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgTmV4dFN0ZXAge1xyXG4gIHN0ZXA6IHN0cmluZztcclxuICBpbXBvcnRhbmNlOiBcIkhpZ2hcIiB8IFwiTWVkaXVtXCIgfCBcIkNvbnNpZGVyXCI7XHJcbiAgZGV0YWlscz86IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBBY3Rpb25hYmxlSW5zaWdodHNEYXRhIHtcclxuICBhY3Rpb25hYmxlSW5zaWdodHM6IHtcclxuICAgIG92ZXJhbGxSZWNvbW1lbmRhdGlvbjogc3RyaW5nO1xyXG4gICAgbmV4dFN0ZXBzOiBOZXh0U3RlcFtdO1xyXG4gIH07XHJcbn1cclxuXHJcbi8vIENvbWJpbmVkIHN0cnVjdHVyZSBmb3IgRHluYW1vREJcclxuZXhwb3J0IGludGVyZmFjZSBBSUFuYWx5c2lzUmVzdWx0cyBleHRlbmRzIEluaXRpYWxBbmFseXNpc1Jlc3VsdHMsIEFjdGlvbmFibGVJbnNpZ2h0c0RhdGEge31cclxuXHJcbi8vIC0tLSBTY2hlbWEgZm9yIHRoZSBmaXJzdCBBSSBjYWxsIChJbml0aWFsIEFuYWx5c2lzKSAtLS1cclxuY29uc3QgaW5pdGlhbEFuYWx5c2lzSnNvblNjaGVtYSA9IHtcclxuICB0eXBlOiBcIm9iamVjdFwiLFxyXG4gIHByb3BlcnRpZXM6IHtcclxuICAgIHN1bW1hcnk6IHsgXHJcbiAgICAgIHR5cGU6IFwic3RyaW5nXCIsIFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJBIGNvbmNpc2Ugb3ZlcmFsbCBzdW1tYXJ5IG9mIHRoZSBsZWFzZSBhZ3JlZW1lbnQsIGhpZ2hsaWdodGluZyBpdHMgbWFpbiBwdXJwb3NlIGFuZCBhbnkgaW1tZWRpYXRlIHN0YW5kb3V0IG9ic2VydmF0aW9ucy5cIlxyXG4gICAgfSxcclxuICAgIG92ZXJhbGxTZXZlcml0eToge1xyXG4gICAgICB0eXBlOiBcInN0cmluZ1wiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJBbiBvdmVyYWxsIHJpc2sgYXNzZXNzbWVudCBmb3IgdGhlIGxlYXNlLCBjYXRlZ29yaXplZCBhcyAnSGlnaCcsICdNZWRpdW0nLCBvciAnTG93Jy4gVGhpcyBzaG91bGQgYmUgYmFzZWQgb24gdGhlIG51bWJlciBhbmQgc2V2ZXJpdHkgb2YgaWRlbnRpZmllZCBpc3N1ZXMuXCIsXHJcbiAgICAgIGVudW06IFtcIkhpZ2hcIiwgXCJNZWRpdW1cIiwgXCJMb3dcIl1cclxuICAgIH0sXHJcbiAgICBjbGF1c2VzOiB7XHJcbiAgICAgIHR5cGU6IFwiYXJyYXlcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiQW4gYXJyYXkgb2YgaW1wb3J0YW50IGNsYXVzZXMgZXh0cmFjdGVkIGZyb20gdGhlIGxlYXNlIGRvY3VtZW50LlwiLFxyXG4gICAgICBpdGVtczoge1xyXG4gICAgICAgIHR5cGU6IFwib2JqZWN0XCIsXHJcbiAgICAgICAgcHJvcGVydGllczoge1xyXG4gICAgICAgICAgdGl0bGU6IHsgXHJcbiAgICAgICAgICAgIHR5cGU6IFwic3RyaW5nXCIsIFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJBIGNsZWFyLCBjb25jaXNlIHRpdGxlIGZvciB0aGUgY2xhdXNlIChlLmcuLCAnUmVudCBQYXltZW50IFRlcm1zJywgJ1N1YmxldHRpbmcgUmVzdHJpY3Rpb25zJywgJ01haW50ZW5hbmNlIFJlc3BvbnNpYmlsaXRpZXMnKS5cIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHRleHQ6IHsgXHJcbiAgICAgICAgICAgIHR5cGU6IFwic3RyaW5nXCIsIFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGUgdmVyYmF0aW0gdGV4dCBvZiB0aGUgY2xhdXNlIGFzIGl0IGFwcGVhcnMgaW4gdGhlIGxlYXNlIGRvY3VtZW50LlwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgaXNzdWVzOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IFwiYXJyYXlcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiQSBsaXN0IG9mIHBvdGVudGlhbCBpc3N1ZXMsIGNvbmNlcm5zLCBvciBwb2ludHMgb2YgYXR0ZW50aW9uIGlkZW50aWZpZWQgd2l0aGluIHRoaXMgc3BlY2lmaWMgY2xhdXNlLlwiLFxyXG4gICAgICAgICAgICBpdGVtczoge1xyXG4gICAgICAgICAgICAgIHR5cGU6IFwib2JqZWN0XCIsXHJcbiAgICAgICAgICAgICAgcHJvcGVydGllczoge1xyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHsgXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3RyaW5nXCIsIFxyXG4gICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJBIGNsZWFyIGRlc2NyaXB0aW9uIG9mIHRoZSBwb3RlbnRpYWwgaXNzdWUgb3IgY29uY2Vybi5cIlxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHNldmVyaXR5OiB7XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3RyaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoZSBzZXZlcml0eSBvZiB0aGlzIHNwZWNpZmljIGlzc3VlLCBjYXRlZ29yaXplZCBhcyAnSGlnaCcsICdNZWRpdW0nLCBvciAnTG93Jy5cIixcclxuICAgICAgICAgICAgICAgICAgZW51bTogW1wiSGlnaFwiLCBcIk1lZGl1bVwiLCBcIkxvd1wiXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHJlY29tbWVuZGF0aW9uOiB7XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3RyaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkEgcHJhY3RpY2FsIHJlY29tbWVuZGF0aW9uIG9yIGFjdGlvbiB0aGUgdXNlciBtaWdodCBjb25zaWRlciByZWdhcmRpbmcgdGhpcyBpc3N1ZSAoZS5nLiwgJ1NlZWsgY2xhcmlmaWNhdGlvbiBmcm9tIGxhbmRsb3JkJywgJ0NvbnN1bHQgYSBsZWdhbCBwcm9mZXNzaW9uYWwnLCAnQmUgYXdhcmUgb2YgdGhpcyBpbXBsaWNhdGlvbicpLlwiXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICByZXF1aXJlZDogW1wiZGVzY3JpcHRpb25cIiwgXCJzZXZlcml0eVwiLCBcInJlY29tbWVuZGF0aW9uXCJdXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHJlcXVpcmVkOiBbXCJ0aXRsZVwiLCBcInRleHRcIiwgXCJpc3N1ZXNcIl1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sXHJcbiAgcmVxdWlyZWQ6IFtcInN1bW1hcnlcIiwgXCJvdmVyYWxsU2V2ZXJpdHlcIiwgXCJjbGF1c2VzXCJdXHJcbn07XHJcblxyXG4vLyAtLS0gU2NoZW1hIGZvciB0aGUgc2Vjb25kIEFJIGNhbGwgKEFjdGlvbmFibGUgSW5zaWdodHMpIC0tLVxyXG5jb25zdCBhY3Rpb25hYmxlSW5zaWdodHNKc29uU2NoZW1hID0ge1xyXG4gIHR5cGU6IFwib2JqZWN0XCIsXHJcbiAgcHJvcGVydGllczoge1xyXG4gICAgYWN0aW9uYWJsZUluc2lnaHRzOiB7XHJcbiAgICAgIHR5cGU6IFwib2JqZWN0XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlByb3ZpZGVzIHNtYXJ0IGFkdmljZSBhbmQgYWN0aW9uYWJsZSBuZXh0IHN0ZXBzIGZvciB0aGUgdXNlciBiYXNlZCBvbiB0aGUgb3ZlcmFsbCBhbmFseXNpcy5cIixcclxuICAgICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG92ZXJhbGxSZWNvbW1lbmRhdGlvbjoge1xyXG4gICAgICAgICAgdHlwZTogXCJzdHJpbmdcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkEgYnJpZWYgb3ZlcmFsbCByZWNvbW1lbmRhdGlvbiBvciB0YWtlYXdheSBtZXNzYWdlIGZvciB0aGUgdXNlciBiYXNlZCBvbiB0aGUgbGVhc2UgYW5hbHlzaXMuXCJcclxuICAgICAgICB9LFxyXG4gICAgICAgIG5leHRTdGVwczoge1xyXG4gICAgICAgICAgdHlwZTogXCJhcnJheVwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiQSBsaXN0IG9mIDItNCBjb25jcmV0ZSwgYWN0aW9uYWJsZSBuZXh0IHN0ZXBzIHRoZSB1c2VyIHNob3VsZCBjb25zaWRlci5cIixcclxuICAgICAgICAgIGl0ZW1zOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IFwib2JqZWN0XCIsXHJcbiAgICAgICAgICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAgICAgICBzdGVwOiB7IHR5cGU6IFwic3RyaW5nXCIsIGRlc2NyaXB0aW9uOiBcIkEgc2luZ2xlIGFjdGlvbmFibGUgc3RlcC5cIiB9LFxyXG4gICAgICAgICAgICAgIGltcG9ydGFuY2U6IHsgXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBcInN0cmluZ1wiLCBcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkluZGljYXRlcyB0aGUgaW1wb3J0YW5jZSBvciB1cmdlbmN5IChlLmcuLCAnSGlnaCcsICdNZWRpdW0nLCAnQ29uc2lkZXInKS5cIixcclxuICAgICAgICAgICAgICAgIGVudW06IFtcIkhpZ2hcIiwgXCJNZWRpdW1cIiwgXCJDb25zaWRlclwiXVxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgZGV0YWlsczogeyB0eXBlOiBcInN0cmluZ1wiLCBkZXNjcmlwdGlvbjogXCIoT3B0aW9uYWwpIEZ1cnRoZXIgZGV0YWlscyBvciByYXRpb25hbGUgZm9yIHRoaXMgc3RlcCwgaWYgbmVjZXNzYXJ5LlwiIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmVxdWlyZWQ6IFtcInN0ZXBcIiwgXCJpbXBvcnRhbmNlXCJdXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICByZXF1aXJlZDogW1wib3ZlcmFsbFJlY29tbWVuZGF0aW9uXCIsIFwibmV4dFN0ZXBzXCJdXHJcbiAgICB9XHJcbiAgfSxcclxuICByZXF1aXJlZDogW1wiYWN0aW9uYWJsZUluc2lnaHRzXCJdXHJcbn07XHJcblxyXG4vLyAtLS0gQ29yZSBBSSBQcm9jZXNzaW5nIEZ1bmN0aW9uIChjb3BpZWQgYW5kIGFkYXB0ZWQgZnJvbSBsZWFzZUFuYWx5c2lzTG9naWMudHMpIC0tLVxyXG5hc3luYyBmdW5jdGlvbiBwZXJmb3JtQWlMZWFzZUFuYWx5c2lzSW50ZXJuYWwoXHJcbiAgZXh0cmFjdGVkVGV4dDogc3RyaW5nLFxyXG4gIHVzZXJTZWxlY3RlZFN0YXRlOiBzdHJpbmcgfCB1bmRlZmluZWQsIC8vIENhbiBiZSB1bmRlZmluZWQgaWYgbm90IHByZXNlbnRcclxuICBvcGVuYWlDbGllbnQ6IE9wZW5BSVxyXG4pOiBQcm9taXNlPHsgaW5pdGlhbEFuYWx5c2lzUmVzdWx0czogSW5pdGlhbEFuYWx5c2lzUmVzdWx0czsgYWN0aW9uYWJsZUluc2lnaHRzRGF0YTogQWN0aW9uYWJsZUluc2lnaHRzRGF0YSB9PiB7XHJcbiAgbGV0IGluaXRpYWxBbmFseXNpc1Jlc3VsdHM6IEluaXRpYWxBbmFseXNpc1Jlc3VsdHM7XHJcbiAgbGV0IGFjdGlvbmFibGVJbnNpZ2h0c0RhdGE6IEFjdGlvbmFibGVJbnNpZ2h0c0RhdGE7XHJcbiAgY29uc3Qgc3RhdGVGb3JQcm9tcHQgPSB1c2VyU2VsZWN0ZWRTdGF0ZSB8fCAnZ2VuZXJhbCc7IC8vIEZhbGxiYWNrIGlmIHN0YXRlIGlzIG5vdCBwcm92aWRlZFxyXG5cclxuICAvLyA9PT0gUEhBU0UgMTogSW5pdGlhbCBMZWFzZSBBbmFseXNpcyA9PT1cclxuICB0cnkge1xyXG4gICAgY29uc3Qgc3lzdGVtTWVzc2FnZUluaXRpYWwgPSBgWW91IGFyZSBhIGxlZ2FsIGFzc2lzdGFudCBzcGVjaWFsaXppbmcgaW4gJHtzdGF0ZUZvclByb21wdH0gbGVhc2UgYWdyZWVtZW50cy4gQW5hbHl6ZSB0aGUgbGVhc2UgdGV4dC4gUmVzcG9uZCBPTkxZIHdpdGggYSB2YWxpZCBKU09OIG9iamVjdCBhZGhlcmluZyB0byB0aGlzIHNjaGVtYTogJHtKU09OLnN0cmluZ2lmeShpbml0aWFsQW5hbHlzaXNKc29uU2NoZW1hLCBudWxsLCAyKX1gO1xyXG4gICAgY29uc3QgdXNlck1lc3NhZ2VJbml0aWFsID0gYExlYXNlIHRleHQ6ICR7ZXh0cmFjdGVkVGV4dH1gO1xyXG4gICAgXHJcbiAgICBjb25zb2xlLmxvZygnKEFJIExhbWJkYSkgQ2FsbGluZyBPcGVuQUkgZm9yIGluaXRpYWwgYW5hbHlzaXMuLi4nKTtcclxuICAgIGNvbnN0IHJlc3BvbnNlSW5pdGlhbCA9IGF3YWl0IG9wZW5haUNsaWVudC5jaGF0LmNvbXBsZXRpb25zLmNyZWF0ZSh7XHJcbiAgICAgIG1vZGVsOiBwcm9jZXNzLmVudi5PUEVOQUlfTU9ERUwgfHwgXCJncHQtNG9cIiwgLy8gVXNlIGVudmlyb25tZW50IHZhcmlhYmxlIGZvciBtb2RlbFxyXG4gICAgICBtZXNzYWdlczogW3sgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogc3lzdGVtTWVzc2FnZUluaXRpYWwgfSwgeyByb2xlOiBcInVzZXJcIiwgY29udGVudDogdXNlck1lc3NhZ2VJbml0aWFsIH1dLFxyXG4gICAgICByZXNwb25zZV9mb3JtYXQ6IHsgdHlwZTogXCJqc29uX29iamVjdFwiIH0sXHJcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjIsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByYXdDb250ZW50SW5pdGlhbCA9IHJlc3BvbnNlSW5pdGlhbC5jaG9pY2VzWzBdPy5tZXNzYWdlPy5jb250ZW50O1xyXG4gICAgaWYgKCFyYXdDb250ZW50SW5pdGlhbCkgdGhyb3cgbmV3IEVycm9yKCdJbml0aWFsIGFuYWx5c2lzOiBObyBjb250ZW50IGZyb20gQUkuJyk7XHJcbiAgICBpbml0aWFsQW5hbHlzaXNSZXN1bHRzID0gSlNPTi5wYXJzZShyYXdDb250ZW50SW5pdGlhbCkgYXMgSW5pdGlhbEFuYWx5c2lzUmVzdWx0cztcclxuICAgIGNvbnNvbGUubG9nKCcoQUkgTGFtYmRhKSBJbml0aWFsIGFuYWx5c2lzIHN1Y2Nlc3NmdWwuJyk7XHJcblxyXG4gIH0gY2F0Y2ggKGFpRXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJyhBSSBMYW1iZGEpIEVycm9yIGR1cmluZyBpbml0aWFsIEFJIGFuYWx5c2lzOicsIGFpRXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKGBJbml0aWFsIEFJIEFuYWx5c2lzIEZhaWxlZDogJHthaUVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBhaUVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoYWlFcnJvcil9YCk7XHJcbiAgfVxyXG5cclxuICAvLyA9PT0gUEhBU0UgMjogR2VuZXJhdGUgQWN0aW9uYWJsZSBJbnNpZ2h0cyA9PT1cclxuICB0cnkge1xyXG4gICAgbGV0IGNvbnRleHRGb3JJbnNpZ2h0cyA9IGBTdW1tYXJ5OiAke2luaXRpYWxBbmFseXNpc1Jlc3VsdHMuc3VtbWFyeX0uIE92ZXJhbGwgU2V2ZXJpdHk6ICR7aW5pdGlhbEFuYWx5c2lzUmVzdWx0cy5vdmVyYWxsU2V2ZXJpdHl9LmA7XHJcbiAgICBjb25zdCBoaWdoU2V2ZXJpdHlJc3N1ZXMgPSBpbml0aWFsQW5hbHlzaXNSZXN1bHRzLmNsYXVzZXNcclxuICAgICAgLmZsYXRNYXAoKGM6IENsYXVzZSkgPT4gYy5pc3N1ZXMpXHJcbiAgICAgIC5maWx0ZXIoKGk6IElzc3VlKSA9PiBpLnNldmVyaXR5ID09PSAnSGlnaCcpXHJcbiAgICAgIC5tYXAoKGk6IElzc3VlKSA9PiBpLmRlc2NyaXB0aW9uKTtcclxuICAgIGlmIChoaWdoU2V2ZXJpdHlJc3N1ZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb250ZXh0Rm9ySW5zaWdodHMgKz0gYCBLZXkgaGlnaC1zZXZlcml0eSBpc3N1ZXMgaW5jbHVkZTogJHtoaWdoU2V2ZXJpdHlJc3N1ZXMuam9pbignOyAnKX1gO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHN5c3RlbU1lc3NhZ2VJbnNpZ2h0cyA9IGBCYXNlZCBvbiB0aGUgZm9sbG93aW5nIGxlYXNlIGFuYWx5c2lzIGNvbnRleHQgZm9yIGEgJHtzdGF0ZUZvclByb21wdH0gbGVhc2UsIHByb3ZpZGUgYWN0aW9uYWJsZSBuZXh0IHN0ZXBzIGZvciB0aGUgdXNlci4gUmVzcG9uZCBPTkxZIHdpdGggYSB2YWxpZCBKU09OIG9iamVjdCBhZGhlcmluZyB0byB0aGlzIHNjaGVtYTogJHtKU09OLnN0cmluZ2lmeShhY3Rpb25hYmxlSW5zaWdodHNKc29uU2NoZW1hLCBudWxsLCAyKX1gO1xyXG4gICAgY29uc3QgdXNlck1lc3NhZ2VJbnNpZ2h0cyA9IGBDb250ZXh0OiAke2NvbnRleHRGb3JJbnNpZ2h0cy5zdWJzdHJpbmcoMCwgMzUwMCl9IFBsZWFzZSBwcm92aWRlIGFjdGlvbmFibGUgaW5zaWdodHMuYDtcclxuXHJcbiAgICBjb25zb2xlLmxvZygnKEFJIExhbWJkYSkgQ2FsbGluZyBPcGVuQUkgZm9yIGFjdGlvbmFibGUgaW5zaWdodHMuLi4nKTtcclxuICAgIGNvbnN0IHJlc3BvbnNlSW5zaWdodHMgPSBhd2FpdCBvcGVuYWlDbGllbnQuY2hhdC5jb21wbGV0aW9ucy5jcmVhdGUoe1xyXG4gICAgICBtb2RlbDogcHJvY2Vzcy5lbnYuT1BFTkFJX01PREVMIHx8IFwiZ3B0LTRvXCIsIC8vIFVzZSBlbnZpcm9ubWVudCB2YXJpYWJsZSBmb3IgbW9kZWxcclxuICAgICAgbWVzc2FnZXM6IFt7IHJvbGU6IFwic3lzdGVtXCIsIGNvbnRlbnQ6IHN5c3RlbU1lc3NhZ2VJbnNpZ2h0cyB9LCB7IHJvbGU6IFwidXNlclwiLCBjb250ZW50OiB1c2VyTWVzc2FnZUluc2lnaHRzIH1dLFxyXG4gICAgICByZXNwb25zZV9mb3JtYXQ6IHsgdHlwZTogXCJqc29uX29iamVjdFwiIH0sXHJcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjUsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByYXdDb250ZW50SW5zaWdodHMgPSByZXNwb25zZUluc2lnaHRzLmNob2ljZXNbMF0/Lm1lc3NhZ2U/LmNvbnRlbnQ7XHJcbiAgICBpZiAoIXJhd0NvbnRlbnRJbnNpZ2h0cykgdGhyb3cgbmV3IEVycm9yKCdBY3Rpb25hYmxlIGluc2lnaHRzOiBObyBjb250ZW50IGZyb20gQUkuJyk7XHJcbiAgICBhY3Rpb25hYmxlSW5zaWdodHNEYXRhID0gSlNPTi5wYXJzZShyYXdDb250ZW50SW5zaWdodHMpIGFzIEFjdGlvbmFibGVJbnNpZ2h0c0RhdGE7XHJcbiAgICBjb25zb2xlLmxvZygnKEFJIExhbWJkYSkgQWN0aW9uYWJsZSBpbnNpZ2h0cyBnZW5lcmF0aW9uIHN1Y2Nlc3NmdWwuJyk7XHJcblxyXG4gIH0gY2F0Y2ggKGFpRXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJyhBSSBMYW1iZGEpIEVycm9yIGR1cmluZyBhY3Rpb25hYmxlIGluc2lnaHRzIGdlbmVyYXRpb246JywgYWlFcnJvcik7XHJcbiAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgQWN0aW9uYWJsZSBJbnNpZ2h0cyBHZW5lcmF0aW9uIEZhaWxlZDogJHthaUVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBhaUVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoYWlFcnJvcil9YCk7XHJcbiAgICAoZXJyb3IgYXMgYW55KS5wYXJ0aWFsUmVzdWx0cyA9IGluaXRpYWxBbmFseXNpc1Jlc3VsdHM7IC8vIEF0dGFjaCBwYXJ0aWFsIHJlc3VsdHNcclxuICAgIHRocm93IGVycm9yO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHsgaW5pdGlhbEFuYWx5c2lzUmVzdWx0cywgYWN0aW9uYWJsZUluc2lnaHRzRGF0YSB9O1xyXG59XHJcblxyXG5jb25zdCBEWU5BTU9EQl9UQUJMRSA9IHByb2Nlc3MuZW52LkRZTkFNT0RCX0xFQVNFX0FOQUxZU0VTX1RBQkxFO1xyXG5jb25zdCBPUEVOQUlfQVBJX0tFWV9TRUNSRVRfTkFNRSA9IHByb2Nlc3MuZW52Lk9QRU5BSV9BUElfS0VZX1NFQ1JFVF9OQU1FO1xyXG5jb25zdCBBV1NfUkVHSU9OID0gcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTjtcclxuXHJcbmlmICghRFlOQU1PREJfVEFCTEUpIHtcclxuICB0aHJvdyBuZXcgRXJyb3IoXCJEWU5BTU9EQl9MRUFTRV9BTkFMWVNFU19UQUJMRSBlbnZpcm9ubWVudCB2YXJpYWJsZSBpcyBub3Qgc2V0LlwiKTtcclxufVxyXG5pZiAoIU9QRU5BSV9BUElfS0VZX1NFQ1JFVF9OQU1FKSB7XHJcbiAgdGhyb3cgbmV3IEVycm9yKFwiT1BFTkFJX0FQSV9LRVlfU0VDUkVUX05BTUUgZW52aXJvbm1lbnQgdmFyaWFibGUgaXMgbm90IHNldC5cIik7XHJcbn1cclxuaWYgKCFBV1NfUkVHSU9OKSB7XHJcbiAgdGhyb3cgbmV3IEVycm9yKFwiQVdTX1JFR0lPTiBlbnZpcm9ubWVudCB2YXJpYWJsZSBpcyBub3Qgc2V0LlwiKTtcclxufVxyXG5cclxuY29uc3QgZHluYW1vREJDbGllbnQgPSBuZXcgRHluYW1vREJDbGllbnQoeyByZWdpb246IEFXU19SRUdJT04gfSk7XHJcbmNvbnN0IGRvY0NsaWVudCA9IER5bmFtb0RCRG9jdW1lbnRDbGllbnQuZnJvbShkeW5hbW9EQkNsaWVudCk7XHJcbmxldCBvcGVuYWlDbGllbnQ6IE9wZW5BSTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGluaXRpYWxpemVPcGVuQUlDbGllbnQoKTogUHJvbWlzZTxPcGVuQUk+IHtcclxuICBpZiAob3BlbmFpQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gb3BlbmFpQ2xpZW50O1xyXG4gIH1cclxuICBjb25zb2xlLmxvZyhgRmV0Y2hpbmcgT3BlbkFJIEFQSSBrZXkgZnJvbSBTZWNyZXRzIE1hbmFnZXI6ICR7T1BFTkFJX0FQSV9LRVlfU0VDUkVUX05BTUV9YCk7XHJcbiAgY29uc3Qgc2VjcmV0c0NsaWVudCA9IG5ldyBTZWNyZXRzTWFuYWdlckNsaWVudCh7IHJlZ2lvbjogQVdTX1JFR0lPTiB9KTtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBHZXRTZWNyZXRWYWx1ZUNvbW1hbmQoeyBTZWNyZXRJZDogT1BFTkFJX0FQSV9LRVlfU0VDUkVUX05BTUUgfSk7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgc2VjcmV0c0NsaWVudC5zZW5kKGNvbW1hbmQpO1xyXG4gICAgbGV0IHNlY3JldFZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQ7XHJcbiAgICBpZiAoZGF0YS5TZWNyZXRTdHJpbmcpIHtcclxuICAgICAgc2VjcmV0VmFsdWUgPSBkYXRhLlNlY3JldFN0cmluZztcclxuICAgIH0gZWxzZSBpZiAoZGF0YS5TZWNyZXRCaW5hcnkpIHtcclxuICAgICAgLy8gSWYgU2VjcmV0QmluYXJ5IGlzIHVzZWQsIHlvdSBuZWVkIHRvIGRlY29kZSBpdCAoZS5nLiwgYmFzZTY0KVxyXG4gICAgICAvLyBGb3IgdGhpcyBleGFtcGxlLCBhc3N1bWluZyBTZWNyZXRTdHJpbmdcclxuICAgICAgY29uc29sZS53YXJuKFwiT3BlbkFJIEFQSSBLZXkgc2VjcmV0IGlzIGJpbmFyeSwgZXhwZWN0ZWQgc3RyaW5nLlwiKTtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiT3BlbkFJIEFQSSBLZXkgc2VjcmV0IGlzIGJpbmFyeSwgZXhwZWN0ZWQgc3RyaW5nLlwiKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIXNlY3JldFZhbHVlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIk9wZW5BSSBBUEkgS2V5IHNlY3JldCBzdHJpbmcgaXMgZW1wdHkuXCIpO1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlJldHJpZXZlZCBPcGVuQUkgQVBJIEtleSBzZWNyZXQgaXMgZW1wdHkuXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFRyeSB0byBwYXJzZSBhcyBKU09OLCBpZiBpdCBmYWlscywgYXNzdW1lIGl0J3MgYSBwbGFpbiBzdHJpbmcga2V5XHJcbiAgICBsZXQgYXBpS2V5O1xyXG4gICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBzZWNyZXRKc29uID0gSlNPTi5wYXJzZShzZWNyZXRWYWx1ZSk7XHJcbiAgICAgICAgLy8gQWRqdXN0IHRoaXMgaWYgeW91ciBzZWNyZXQgaXMgc3RvcmVkIHdpdGggYSBkaWZmZXJlbnQga2V5IHdpdGhpbiB0aGUgSlNPTlxyXG4gICAgICAgIGFwaUtleSA9IHNlY3JldEpzb24uT1BFTkFJX0FQSV9LRVkgfHwgc2VjcmV0SnNvbi5hcGlLZXkgfHwgc2VjcmV0SnNvbi5rZXk7XHJcbiAgICAgICAgaWYgKCFhcGlLZXkgJiYgdHlwZW9mIHNlY3JldEpzb24gPT09ICdzdHJpbmcnKSBhcGlLZXkgPSBzZWNyZXRKc29uOyAvLyBpZiBKU09OIGlzIGp1c3QgdGhlIGtleSBzdHJpbmcgaXRzZWxmXHJcbiAgICAgICAgZWxzZSBpZiAoIWFwaUtleSkgYXBpS2V5ID0gc2VjcmV0VmFsdWU7IC8vIEZhbGxiYWNrIGlmIGtleSBub3QgZm91bmQgaW4gSlNPTiBzdHJ1Y3R1cmVcclxuXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgLy8gTm90IGEgSlNPTiBzdHJpbmcsIGFzc3VtZSB0aGUgc2VjcmV0IElTIHRoZSBBUEkga2V5XHJcbiAgICAgICAgYXBpS2V5ID0gc2VjcmV0VmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFhcGlLZXkpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmFibGUgdG8gZXh0cmFjdCBPcGVuQUkgQVBJIEtleSBmcm9tIHNlY3JldC5cIik7XHJcbiAgICB9XHJcblxyXG4gICAgb3BlbmFpQ2xpZW50ID0gbmV3IE9wZW5BSSh7IGFwaUtleSB9KTtcclxuICAgIGNvbnNvbGUubG9nKFwiT3BlbkFJIGNsaWVudCBpbml0aWFsaXplZCBzdWNjZXNzZnVsbHkuXCIpO1xyXG4gICAgcmV0dXJuIG9wZW5haUNsaWVudDtcclxuXHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcvcGFyc2luZyBPcGVuQUkgQVBJIGtleSBmcm9tIFNlY3JldHMgTWFuYWdlcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHJldHJpZXZlL3BhcnNlIE9wZW5BSSBBUEkgS2V5OiAke2VyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKX1gKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKGV2ZW50OiBhbnksIGNvbnRleHQ6IGFueSk6IFByb21pc2U8dm9pZD4gPT4ge1xyXG4gIGNvbnNvbGUubG9nKCdBSSBMZWFzZSBQcm9jZXNzaW5nIExhbWJkYSBpbnZva2VkLiBFdmVudDonLCBKU09OLnN0cmluZ2lmeShldmVudCwgbnVsbCwgMikpO1xyXG4gIFxyXG4gIHRyeSB7XHJcbiAgICBvcGVuYWlDbGllbnQgPSBhd2FpdCBpbml0aWFsaXplT3BlbkFJQ2xpZW50KCk7IFxyXG4gIH0gY2F0Y2ggKGluaXRFcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBpbml0aWFsaXplIE9wZW5BSSBjbGllbnQ6XCIsIGluaXRFcnJvcik7XHJcbiAgICB0aHJvdyBpbml0RXJyb3I7XHJcbiAgfVxyXG5cclxuICBmb3IgKGNvbnN0IHJlY29yZCBvZiBldmVudC5SZWNvcmRzKSB7XHJcbiAgICBsZXQgYW5hbHlzaXNJZDogc3RyaW5nIHwgdW5kZWZpbmVkO1xyXG4gICAgbGV0IHNxc01lc3NhZ2VCb2R5OiBhbnk7IC8vIFRvIHN0b3JlIHRoZSBwYXJzZWQgYm9keSBmb3Igd2lkZXIgdXNlXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc3FzTWVzc2FnZUJvZHkgPSBKU09OLnBhcnNlKHJlY29yZC5ib2R5KTtcclxuICAgICAgYW5hbHlzaXNJZCA9IHNxc01lc3NhZ2VCb2R5LmFuYWx5c2lzSWQ7XHJcbiAgICAgIGNvbnN0IHVzZXJVcGxvYWRlZEZpbGVOYW1lID0gc3FzTWVzc2FnZUJvZHkub3JpZ2luYWxGaWxlTmFtZSB8fCBzcXNNZXNzYWdlQm9keS51c2VyVXBsb2FkZWRGaWxlTmFtZTsgLy8gVXNlIG9yaWdpbmFsRmlsZU5hbWUgZnJvbSBTUVNcclxuXHJcbiAgICAgIGlmICghYW5hbHlzaXNJZCkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJhbmFseXNpc0lkIGlzIG1pc3NpbmcgaW4gU1FTIG1lc3NhZ2UgYm9keTpcIiwgc3FzTWVzc2FnZUJvZHkpO1xyXG4gICAgICAgIGNvbnRpbnVlOyBcclxuICAgICAgfVxyXG4gICAgICAvLyBFbnN1cmUgY3JpdGljYWwgZGF0YSBmcm9tIFNRUyBtZXNzYWdlIGlzIHByZXNlbnRcclxuICAgICAgaWYgKCFzcXNNZXNzYWdlQm9keS5leHRyYWN0ZWRUZXh0KSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXh0cmFjdGVkIHRleHQgaXMgbWlzc2luZyBpbiBTUVMgbWVzc2FnZSBib2R5IGZvciBhbmFseXNpc0lkOiAke2FuYWx5c2lzSWR9YCk7XHJcbiAgICAgICAgLy8gVXBkYXRlIEREQiB3aXRoIGVycm9yIGFuZCBjb250aW51ZVxyXG4gICAgICAgIGF3YWl0IHVwZGF0ZUR5bmFtb0RCT25FcnJvcihhbmFseXNpc0lkLCBcIkFJX1BST0NFU1NJTkdfRkFJTEVEXCIsIFwiTWlzc2luZyBleHRyYWN0ZWRUZXh0IGluIFNRUyBtZXNzYWdlXCIpO1xyXG4gICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghc3FzTWVzc2FnZUJvZHkudXNlclNlbGVjdGVkU3RhdGUpIHtcclxuICAgICAgICBjb25zb2xlLndhcm4oYHVzZXJTZWxlY3RlZFN0YXRlIGlzIG1pc3NpbmcgaW4gU1FTIG1lc3NhZ2UgYm9keSBmb3IgYW5hbHlzaXNJZDogJHthbmFseXNpc0lkfS4gQUkgd2lsbCB1c2UgYSBnZW5lcmFsIHByb21wdC5gKTtcclxuICAgICAgICAvLyBBSSBmdW5jdGlvbiBoYXMgYSBmYWxsYmFjaywgc28gdGhpcyBpcyBub3QgZmF0YWwsIGJ1dCBnb29kIHRvIGxvZy5cclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgYW5hbHlzaXNJZDogJHthbmFseXNpc0lkfSBmb3IgZmlsZTogJHt1c2VyVXBsb2FkZWRGaWxlTmFtZSB8fCAnTi9BJ31gKTtcclxuXHJcbiAgICAgIC8vIDEuIERhdGEgZGlyZWN0bHkgZnJvbSBTUVMgbWVzc2FnZSBib2R5XHJcbiAgICAgIGNvbnN0IGV4dHJhY3RlZFRleHQgPSBzcXNNZXNzYWdlQm9keS5leHRyYWN0ZWRUZXh0IGFzIHN0cmluZztcclxuICAgICAgY29uc3QgdXNlclNlbGVjdGVkU3RhdGUgPSBzcXNNZXNzYWdlQm9keS51c2VyU2VsZWN0ZWRTdGF0ZSBhcyBzdHJpbmcgfCB1bmRlZmluZWQ7XHJcbiAgICAgIC8vIHMzS2V5LCBzM0J1Y2tldCBhcmUgYWxzbyBhdmFpbGFibGUgaW4gc3FzTWVzc2FnZUJvZHkgaWYgbmVlZGVkIGxhdGVyXHJcblxyXG4gICAgICAvLyAyLiBVcGRhdGUgc3RhdHVzIHRvIEFJX1BST0NFU1NJTkdfSU5fUFJPR1JFU1NcclxuICAgICAgY29uc29sZS5sb2coYFVwZGF0aW5nIHN0YXR1cyB0byBBSV9QUk9DRVNTSU5HX0lOX1BST0dSRVNTIGZvciAke2FuYWx5c2lzSWR9YCk7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZUluUHJvZ3Jlc3NQYXJhbXMgPSB7XHJcbiAgICAgICAgVGFibGVOYW1lOiBEWU5BTU9EQl9UQUJMRSEsXHJcbiAgICAgICAgS2V5OiB7IGFuYWx5c2lzSWQgfSxcclxuICAgICAgICBVcGRhdGVFeHByZXNzaW9uOiBcInNldCAjc3RhdHVzID0gOnN0YXR1cywgI2xhc3RVcGRhdGVkVGltZXN0YW1wID0gOnRpbWVzdGFtcFwiLFxyXG4gICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVOYW1lczogeyBcIiNzdGF0dXNcIjogXCJzdGF0dXNcIiwgXCIjbGFzdFVwZGF0ZWRUaW1lc3RhbXBcIjogXCJsYXN0VXBkYXRlZFRpbWVzdGFtcFwiIH0sXHJcbiAgICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczoge1xyXG4gICAgICAgICAgXCI6c3RhdHVzXCI6IFwiQUlfUFJPQ0VTU0lOR19JTl9QUk9HUkVTU1wiLFxyXG4gICAgICAgICAgXCI6dGltZXN0YW1wXCI6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICB9LFxyXG4gICAgICB9O1xyXG4gICAgICBhd2FpdCBkb2NDbGllbnQuc2VuZChuZXcgVXBkYXRlQ29tbWFuZCh1cGRhdGVJblByb2dyZXNzUGFyYW1zKSk7XHJcblxyXG4gICAgICBsZXQgZmluYWxSZXN1bHRzOiBBSUFuYWx5c2lzUmVzdWx0cyB8IG51bGwgPSBudWxsO1xyXG4gICAgICBsZXQgZmluYWxTdGF0dXM6IHN0cmluZyA9ICcnO1xyXG4gICAgICBsZXQgZXJyb3JEZXRhaWxzOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8gMy4gUGVyZm9ybSBBSSBBbmFseXNpcyB1c2luZyBkYXRhIGZyb20gU1FTIG1lc3NhZ2VcclxuICAgICAgICBjb25zb2xlLmxvZyhgUGVyZm9ybWluZyBBSSBhbmFseXNpcyBmb3IgJHthbmFseXNpc0lkfSB1c2luZyB0ZXh0IG9mIGxlbmd0aCAke2V4dHJhY3RlZFRleHQubGVuZ3RofSBmb3Igc3RhdGU6ICR7dXNlclNlbGVjdGVkU3RhdGUgfHwgJ2dlbmVyYWwnfWApO1xyXG4gICAgICAgIGNvbnN0IHsgaW5pdGlhbEFuYWx5c2lzUmVzdWx0cywgYWN0aW9uYWJsZUluc2lnaHRzRGF0YSB9ID0gYXdhaXQgcGVyZm9ybUFpTGVhc2VBbmFseXNpc0ludGVybmFsKFxyXG4gICAgICAgICAgZXh0cmFjdGVkVGV4dCwgICAgICAgICAgLy8gRnJvbSBTUVMgbWVzc2FnZVxyXG4gICAgICAgICAgdXNlclNlbGVjdGVkU3RhdGUsICAgICAgLy8gRnJvbSBTUVMgbWVzc2FnZVxyXG4gICAgICAgICAgb3BlbmFpQ2xpZW50XHJcbiAgICAgICAgKTtcclxuICAgICAgICBmaW5hbFJlc3VsdHMgPSB7IC4uLmluaXRpYWxBbmFseXNpc1Jlc3VsdHMsIC4uLmFjdGlvbmFibGVJbnNpZ2h0c0RhdGEgfTtcclxuICAgICAgICBmaW5hbFN0YXR1cyA9ICdBTkFMWVNJU19DT01QTEVURSc7XHJcbiAgICAgICAgY29uc29sZS5sb2coYEFJIGFuYWx5c2lzIHN1Y2Nlc3NmdWwgZm9yICR7YW5hbHlzaXNJZH1gKTtcclxuXHJcbiAgICAgIH0gY2F0Y2ggKGFpRXJyb3I6IGFueSkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGR1cmluZyBBSSBwcm9jZXNzaW5nIGZvciAke2FuYWx5c2lzSWR9OmAsIGFpRXJyb3IpO1xyXG4gICAgICAgIGZpbmFsU3RhdHVzID0gJ0FJX1BST0NFU1NJTkdfRkFJTEVEJztcclxuICAgICAgICBlcnJvckRldGFpbHMgPSBhaUVycm9yLm1lc3NhZ2UgfHwgXCJVbmtub3duIEFJIHByb2Nlc3NpbmcgZXJyb3IuXCI7XHJcbiAgICAgICAgaWYgKGFpRXJyb3IucGFydGlhbFJlc3VsdHMpIHtcclxuICAgICAgICAgICAgLy8gSWYgYWN0aW9uYWJsZSBpbnNpZ2h0cyBmYWlsZWQsIGJ1dCBpbml0aWFsIGFuYWx5c2lzIHN1Y2NlZWRlZFxyXG4gICAgICAgICAgICBmaW5hbFJlc3VsdHMgPSB7IC4uLihhaUVycm9yLnBhcnRpYWxSZXN1bHRzIGFzIEluaXRpYWxBbmFseXNpc1Jlc3VsdHMpLCBhY3Rpb25hYmxlSW5zaWdodHM6IHsgb3ZlcmFsbFJlY29tbWVuZGF0aW9uOiBcIlwiLCBuZXh0U3RlcHM6IFtdfSB9O1xyXG4gICAgICAgICAgICBmaW5hbFN0YXR1cyA9ICdQQVJUSUFMX0FOQUxZU0lTX0lOU0lHSFRTX0ZBSUxFRCc7XHJcbiAgICAgICAgICAgIGVycm9yRGV0YWlscyA9IGBJbnNpZ2h0czogJHtlcnJvckRldGFpbHN9YDtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coYFBhcnRpYWwgcmVzdWx0cyBzYXZlZCBmb3IgJHthbmFseXNpc0lkfSBkdWUgdG8gaW5zaWdodHMgZmFpbHVyZS5gKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIDQuIFVwZGF0ZSBEeW5hbW9EQiB3aXRoIGZpbmFsIHJlc3VsdHMvc3RhdHVzXHJcbiAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGluZyBzdGF0dXMgdG8gJHtmaW5hbFN0YXR1c30gZm9yICR7YW5hbHlzaXNJZH1gKTtcclxuICAgICAgY29uc3QgdXBkYXRlRmluYWxQYXJhbXM6IGFueSA9IHtcclxuICAgICAgICBUYWJsZU5hbWU6IERZTkFNT0RCX1RBQkxFISxcclxuICAgICAgICBLZXk6IHsgYW5hbHlzaXNJZCB9LFxyXG4gICAgICAgIFVwZGF0ZUV4cHJlc3Npb246IFwic2V0ICNzdGF0dXMgPSA6c3RhdHVzLCAjYW5hbHlzaXNSZXN1bHRzID0gOmFuYWx5c2lzUmVzdWx0cywgI2xhc3RVcGRhdGVkVGltZXN0YW1wID0gOnRpbWVzdGFtcFwiLFxyXG4gICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVOYW1lczoge1xyXG4gICAgICAgICAgXCIjc3RhdHVzXCI6IFwic3RhdHVzXCIsXHJcbiAgICAgICAgICBcIiNhbmFseXNpc1Jlc3VsdHNcIjogXCJhbmFseXNpc1Jlc3VsdHNcIixcclxuICAgICAgICAgIFwiI2xhc3RVcGRhdGVkVGltZXN0YW1wXCI6IFwibGFzdFVwZGF0ZWRUaW1lc3RhbXBcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IHtcclxuICAgICAgICAgIFwiOnN0YXR1c1wiOiBmaW5hbFN0YXR1cyxcclxuICAgICAgICAgIFwiOmFuYWx5c2lzUmVzdWx0c1wiOiBmaW5hbFJlc3VsdHMsIC8vIFN0b3JlIHRoZSBjb21iaW5lZCByZXN1bHRzXHJcbiAgICAgICAgICBcIjp0aW1lc3RhbXBcIjogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH07XHJcbiAgICAgIGlmIChlcnJvckRldGFpbHMpIHtcclxuICAgICAgICB1cGRhdGVGaW5hbFBhcmFtcy5VcGRhdGVFeHByZXNzaW9uICs9IFwiLCAjZXJyb3JEZXRhaWxzID0gOmVycm9yRGV0YWlsc1wiO1xyXG4gICAgICAgIHVwZGF0ZUZpbmFsUGFyYW1zLkV4cHJlc3Npb25BdHRyaWJ1dGVOYW1lc1tcIiNlcnJvckRldGFpbHNcIl0gPSBcImVycm9yRGV0YWlsc1wiO1xyXG4gICAgICAgIHVwZGF0ZUZpbmFsUGFyYW1zLkV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXNbXCI6ZXJyb3JEZXRhaWxzXCJdID0gZXJyb3JEZXRhaWxzO1xyXG4gICAgICB9XHJcbiAgICAgIGF3YWl0IGRvY0NsaWVudC5zZW5kKG5ldyBVcGRhdGVDb21tYW5kKHVwZGF0ZUZpbmFsUGFyYW1zKSk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGBTdWNjZXNzZnVsbHkgcHJvY2Vzc2VkIGFuZCB1cGRhdGVkICR7YW5hbHlzaXNJZH0uIFN0YXR1czogJHtmaW5hbFN0YXR1c31gKTtcclxuXHJcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBwcm9jZXNzIFNRUyByZWNvcmQgZm9yIGFuYWx5c2lzSWQgJHthbmFseXNpc0lkIHx8ICd1bmtub3duJ306YCwgZXJyb3IpO1xyXG4gICAgICAvLyBJZiBhbmFseXNpc0lkIGlzIGtub3duIGFuZCBlcnJvciBpcyBub3QgZHVyaW5nIGZpbmFsIEREQiB1cGRhdGUsIHRyeSB0byB1cGRhdGUgRERCIHdpdGggZXJyb3Igc3RhdHVzXHJcbiAgICAgIGlmIChhbmFseXNpc0lkKSB7IFxyXG4gICAgICAgIGF3YWl0IHVwZGF0ZUR5bmFtb0RCT25FcnJvcihhbmFseXNpc0lkLCAnQUlfUFJPQ0VTU0lOR19GQUlMRUQnLCBlcnJvci5tZXNzYWdlIHx8ICdVbmtub3duIGVycm9yIGR1cmluZyBTUVMgcmVjb3JkIHByb2Nlc3NpbmcnKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufTtcclxuXHJcbi8vIEhlbHBlciBmdW5jdGlvbiB0byB1cGRhdGUgRHluYW1vREIgb24gZXJyb3IsIHRvIGF2b2lkIGNvZGUgZHVwbGljYXRpb24gaW4gY2F0Y2ggYmxvY2tzXHJcbmFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUR5bmFtb0RCT25FcnJvcihhbmFseXNpc0lkOiBzdHJpbmcsIHN0YXR1czogc3RyaW5nLCBlcnJvck1lc3NhZ2U6IHN0cmluZykge1xyXG4gICAgY29uc29sZS5sb2coYFVwZGF0aW5nIER5bmFtb0RCIGZvciAke2FuYWx5c2lzSWR9IHdpdGggZXJyb3Igc3RhdHVzICR7c3RhdHVzfSBkdWUgdG86ICR7ZXJyb3JNZXNzYWdlfWApO1xyXG4gICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBlcnJvclVwZGF0ZVBhcmFtcyA9IHtcclxuICAgICAgICAgICAgVGFibGVOYW1lOiBEWU5BTU9EQl9UQUJMRSEsXHJcbiAgICAgICAgICAgIEtleTogeyBhbmFseXNpc0lkIH0sXHJcbiAgICAgICAgICAgIFVwZGF0ZUV4cHJlc3Npb246IFwic2V0ICNzdGF0dXMgPSA6c3RhdHVzLCAjZXJyb3JEZXRhaWxzID0gOmVycm9yRGV0YWlscywgI2xhc3RVcGRhdGVkVGltZXN0YW1wID0gOnRpbWVzdGFtcFwiLFxyXG4gICAgICAgICAgICBFeHByZXNzaW9uQXR0cmlidXRlTmFtZXM6IHsgXHJcbiAgICAgICAgICAgICAgICBcIiNzdGF0dXNcIjogXCJzdGF0dXNcIiwgXHJcbiAgICAgICAgICAgICAgICBcIiNlcnJvckRldGFpbHNcIjogXCJlcnJvckRldGFpbHNcIixcclxuICAgICAgICAgICAgICAgIFwiI2xhc3RVcGRhdGVkVGltZXN0YW1wXCI6IFwibGFzdFVwZGF0ZWRUaW1lc3RhbXBcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBFeHByZXNzaW9uQXR0cmlidXRlVmFsdWVzOiB7XHJcbiAgICAgICAgICAgICAgICBcIjpzdGF0dXNcIjogc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgXCI6ZXJyb3JEZXRhaWxzXCI6IGVycm9yTWVzc2FnZS5zdWJzdHJpbmcoMCwgMjAwMCksIC8vIENhcCBlcnJvciBtZXNzYWdlIGxlbmd0aFxyXG4gICAgICAgICAgICAgICAgXCI6dGltZXN0YW1wXCI6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGF3YWl0IGRvY0NsaWVudC5zZW5kKG5ldyBVcGRhdGVDb21tYW5kKGVycm9yVXBkYXRlUGFyYW1zKSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coYFN1Y2Nlc3NmdWxseSB1cGRhdGVkICR7YW5hbHlzaXNJZH0gd2l0aCBlcnJvciBzdGF0dXMuYCk7XHJcbiAgICB9IGNhdGNoIChkYkVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIHVwZGF0ZSBEeW5hbW9EQiB3aXRoIGVycm9yIHN0YXR1cyBmb3IgJHthbmFseXNpc0lkfTpgLCBkYkVycm9yKTtcclxuICAgICAgICAvLyBTd2FsbG93IHRoaXMgZXJyb3IgYXMgdGhlIG1haW4gZXJyb3IgaXMgYWxyZWFkeSBsb2dnZWQuXHJcbiAgICB9XHJcbn0gIl19