import OpenAI from 'openai';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

// --- TypeScript Interfaces for AI Schemas (copied from leaseAnalysisLogic.ts) ---
export interface Issue {
  description: string;
  severity: "High" | "Medium" | "Low";
  recommendation: string;
}

export interface Clause {
  title: string;
  text: string;
  issues: Issue[];
}

export interface InitialAnalysisResults {
  summary: string;
  overallSeverity: "High" | "Medium" | "Low";
  clauses: Clause[];
}

export interface NextStep {
  step: string;
  importance: "High" | "Medium" | "Consider";
  details?: string;
}

export interface ActionableInsightsData {
  actionableInsights: {
    overallRecommendation: string;
    nextSteps: NextStep[];
  };
}

// Combined structure for DynamoDB
export interface AIAnalysisResults extends InitialAnalysisResults, ActionableInsightsData {}

// --- Schema for the first AI call (Initial Analysis) ---
const initialAnalysisJsonSchema = {
  type: "object",
  properties: {
    summary: { 
      type: "string", 
      description: "A concise overall summary of the lease agreement, highlighting its main purpose and any immediate standout observations."
    },
    overallSeverity: {
      type: "string",
      description: "An overall risk assessment for the lease, categorized as 'High', 'Medium', or 'Low'. This should be based on the number and severity of identified issues.",
      enum: ["High", "Medium", "Low"]
    },
    clauses: {
      type: "array",
      description: "An array of important clauses extracted from the lease document.",
      items: {
        type: "object",
        properties: {
          title: { 
            type: "string", 
            description: "A clear, concise title for the clause (e.g., 'Rent Payment Terms', 'Subletting Restrictions', 'Maintenance Responsibilities')."
          },
          text: { 
            type: "string", 
            description: "The verbatim text of the clause as it appears in the lease document."
          },
          issues: {
            type: "array",
            description: "A list of potential issues, concerns, or points of attention identified within this specific clause.",
            items: {
              type: "object",
              properties: {
                description: { 
                  type: "string", 
                  description: "A clear description of the potential issue or concern."
                },
                severity: {
                  type: "string",
                  description: "The severity of this specific issue, categorized as 'High', 'Medium', or 'Low'.",
                  enum: ["High", "Medium", "Low"]
                },
                recommendation: {
                  type: "string",
                  description: "A practical recommendation or action the user might consider regarding this issue (e.g., 'Seek clarification from landlord', 'Consult a legal professional', 'Be aware of this implication')."
                }
              },
              required: ["description", "severity", "recommendation"]
            }
          }
        },
        required: ["title", "text", "issues"]
      }
    }
  },
  required: ["summary", "overallSeverity", "clauses"]
};

// --- Schema for the second AI call (Actionable Insights) ---
const actionableInsightsJsonSchema = {
  type: "object",
  properties: {
    actionableInsights: {
      type: "object",
      description: "Provides smart advice and actionable next steps for the user based on the overall analysis.",
      properties: {
        overallRecommendation: {
          type: "string",
          description: "A brief overall recommendation or takeaway message for the user based on the lease analysis."
        },
        nextSteps: {
          type: "array",
          description: "A list of 2-4 concrete, actionable next steps the user should consider.",
          items: {
            type: "object",
            properties: {
              step: { type: "string", description: "A single actionable step." },
              importance: { 
                type: "string", 
                description: "Indicates the importance or urgency (e.g., 'High', 'Medium', 'Consider').",
                enum: ["High", "Medium", "Consider"]
              },
              details: { type: "string", description: "(Optional) Further details or rationale for this step, if necessary." }
            },
            required: ["step", "importance"]
          }
        }
      },
      required: ["overallRecommendation", "nextSteps"]
    }
  },
  required: ["actionableInsights"]
};

// --- Core AI Processing Function (copied and adapted from leaseAnalysisLogic.ts) ---
async function performAiLeaseAnalysisInternal(
  extractedText: string,
  userSelectedState: string | undefined, // Can be undefined if not present
  openaiClient: OpenAI
): Promise<{ initialAnalysisResults: InitialAnalysisResults; actionableInsightsData: ActionableInsightsData }> {
  let initialAnalysisResults: InitialAnalysisResults;
  let actionableInsightsData: ActionableInsightsData;
  const stateForPrompt = userSelectedState || 'general'; // Fallback if state is not provided

  // === PHASE 1: Initial Lease Analysis ===
  try {
    const systemMessageInitial = `You are a legal assistant specializing in ${stateForPrompt} lease agreements. Analyze the lease text. Respond ONLY with a valid JSON object adhering to this schema: ${JSON.stringify(initialAnalysisJsonSchema, null, 2)}`;
    const userMessageInitial = `Lease text: ${extractedText}`;
    
    console.log('(AI Lambda) Calling OpenAI for initial analysis...');
    const responseInitial = await openaiClient.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o", // Use environment variable for model
      messages: [{ role: "system", content: systemMessageInitial }, { role: "user", content: userMessageInitial }],
      response_format: { type: "json_object" },
      temperature: 0.2,
    });

    const rawContentInitial = responseInitial.choices[0]?.message?.content;
    if (!rawContentInitial) throw new Error('Initial analysis: No content from AI.');
    initialAnalysisResults = JSON.parse(rawContentInitial) as InitialAnalysisResults;
    console.log('(AI Lambda) Initial analysis successful.');

  } catch (aiError) {
    console.error('(AI Lambda) Error during initial AI analysis:', aiError);
    throw new Error(`Initial AI Analysis Failed: ${aiError instanceof Error ? aiError.message : String(aiError)}`);
  }

  // === PHASE 2: Generate Actionable Insights ===
  try {
    let contextForInsights = `Summary: ${initialAnalysisResults.summary}. Overall Severity: ${initialAnalysisResults.overallSeverity}.`;
    const highSeverityIssues = initialAnalysisResults.clauses
      .flatMap((c: Clause) => c.issues)
      .filter((i: Issue) => i.severity === 'High')
      .map((i: Issue) => i.description);
    if (highSeverityIssues.length > 0) {
      contextForInsights += ` Key high-severity issues include: ${highSeverityIssues.join('; ')}`;
    }

    const systemMessageInsights = `Based on the following lease analysis context for a ${stateForPrompt} lease, provide actionable next steps for the user. Respond ONLY with a valid JSON object adhering to this schema: ${JSON.stringify(actionableInsightsJsonSchema, null, 2)}`;
    const userMessageInsights = `Context: ${contextForInsights.substring(0, 3500)} Please provide actionable insights.`;

    console.log('(AI Lambda) Calling OpenAI for actionable insights...');
    const responseInsights = await openaiClient.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o", // Use environment variable for model
      messages: [{ role: "system", content: systemMessageInsights }, { role: "user", content: userMessageInsights }],
      response_format: { type: "json_object" },
      temperature: 0.5,
    });

    const rawContentInsights = responseInsights.choices[0]?.message?.content;
    if (!rawContentInsights) throw new Error('Actionable insights: No content from AI.');
    actionableInsightsData = JSON.parse(rawContentInsights) as ActionableInsightsData;
    console.log('(AI Lambda) Actionable insights generation successful.');

  } catch (aiError) {
    console.error('(AI Lambda) Error during actionable insights generation:', aiError);
    const error = new Error(`Actionable Insights Generation Failed: ${aiError instanceof Error ? aiError.message : String(aiError)}`);
    (error as any).partialResults = initialAnalysisResults; // Attach partial results
    throw error;
  }

  return { initialAnalysisResults, actionableInsightsData };
}

const DYNAMODB_TABLE = process.env.DYNAMODB_LEASE_ANALYSES_TABLE;
const OPENAI_API_KEY_SECRET_NAME = process.env.OPENAI_API_KEY_SECRET_NAME;
const AWS_REGION = process.env.AWS_REGION;

if (!DYNAMODB_TABLE) {
  throw new Error("DYNAMODB_LEASE_ANALYSES_TABLE environment variable is not set.");
}
if (!OPENAI_API_KEY_SECRET_NAME) {
  throw new Error("OPENAI_API_KEY_SECRET_NAME environment variable is not set.");
}
if (!AWS_REGION) {
  throw new Error("AWS_REGION environment variable is not set.");
}

const dynamoDBClient = new DynamoDBClient({ region: AWS_REGION });
const docClient = DynamoDBDocumentClient.from(dynamoDBClient);
let openaiClient: OpenAI;

async function initializeOpenAIClient(): Promise<OpenAI> {
  if (openaiClient) {
    return openaiClient;
  }
  console.log(`Fetching OpenAI API key from Secrets Manager: ${OPENAI_API_KEY_SECRET_NAME}`);
  const secretsClient = new SecretsManagerClient({ region: AWS_REGION });
  try {
    const command = new GetSecretValueCommand({ SecretId: OPENAI_API_KEY_SECRET_NAME });
    const data = await secretsClient.send(command);
    let secretValue: string | undefined;
    if (data.SecretString) {
      secretValue = data.SecretString;
    } else if (data.SecretBinary) {
      // If SecretBinary is used, you need to decode it (e.g., base64)
      // For this example, assuming SecretString
      console.warn("OpenAI API Key secret is binary, expected string.");
      throw new Error("OpenAI API Key secret is binary, expected string.");
    }

    if (!secretValue) {
        console.error("OpenAI API Key secret string is empty.");
        throw new Error("Retrieved OpenAI API Key secret is empty.");
    }

    // Try to parse as JSON, if it fails, assume it's a plain string key
    let apiKey;
    try {
        const secretJson = JSON.parse(secretValue);
        // Adjust this if your secret is stored with a different key within the JSON
        apiKey = secretJson.OPENAI_API_KEY || secretJson.apiKey || secretJson.key;
        if (!apiKey && typeof secretJson === 'string') apiKey = secretJson; // if JSON is just the key string itself
        else if (!apiKey) apiKey = secretValue; // Fallback if key not found in JSON structure

    } catch (e) {
        // Not a JSON string, assume the secret IS the API key
        apiKey = secretValue;
    }

    if (!apiKey) {
        throw new Error("Unable to extract OpenAI API Key from secret.");
    }

    openaiClient = new OpenAI({ apiKey });
    console.log("OpenAI client initialized successfully.");
    return openaiClient;

  } catch (err) {
    console.error("Error fetching/parsing OpenAI API key from Secrets Manager:", err);
    throw new Error(`Failed to retrieve/parse OpenAI API Key: ${err instanceof Error ? err.message : String(err)}`);
  }
}

export const handler = async (event: any, context: any): Promise<void> => {
  console.log('AI Lease Processing Lambda invoked. Event:', JSON.stringify(event, null, 2));
  
  try {
    openaiClient = await initializeOpenAIClient(); 
  } catch (initError) {
    console.error("Failed to initialize OpenAI client:", initError);
    throw initError;
  }

  for (const record of event.Records) {
    let analysisId: string | undefined;
    let sqsMessageBody: any; // To store the parsed body for wider use

    try {
      sqsMessageBody = JSON.parse(record.body);
      analysisId = sqsMessageBody.analysisId;
      const userUploadedFileName = sqsMessageBody.originalFileName || sqsMessageBody.userUploadedFileName; // Use originalFileName from SQS

      if (!analysisId) {
        console.error("analysisId is missing in SQS message body:", sqsMessageBody);
        continue; 
      }
      // Ensure critical data from SQS message is present
      if (!sqsMessageBody.extractedText) {
        console.error(`Extracted text is missing in SQS message body for analysisId: ${analysisId}`);
        // Update DDB with error and continue
        await updateDynamoDBOnError(analysisId, "AI_PROCESSING_FAILED", "Missing extractedText in SQS message");
        continue;
      }
      if (!sqsMessageBody.userSelectedState) {
        console.warn(`userSelectedState is missing in SQS message body for analysisId: ${analysisId}. AI will use a general prompt.`);
        // AI function has a fallback, so this is not fatal, but good to log.
      }

      console.log(`Processing analysisId: ${analysisId} for file: ${userUploadedFileName || 'N/A'}`);

      // 1. Data directly from SQS message body
      const extractedText = sqsMessageBody.extractedText as string;
      const userSelectedState = sqsMessageBody.userSelectedState as string | undefined;
      // s3Key, s3Bucket are also available in sqsMessageBody if needed later

      // 2. Update status to AI_PROCESSING_IN_PROGRESS
      console.log(`Updating status to AI_PROCESSING_IN_PROGRESS for ${analysisId}`);
      const updateInProgressParams = {
        TableName: DYNAMODB_TABLE!,
        Key: { analysisId },
        UpdateExpression: "set #status = :status, #lastUpdatedTimestamp = :timestamp",
        ExpressionAttributeNames: { "#status": "status", "#lastUpdatedTimestamp": "lastUpdatedTimestamp" },
        ExpressionAttributeValues: {
          ":status": "AI_PROCESSING_IN_PROGRESS",
          ":timestamp": new Date().toISOString(),
        },
      };
      await docClient.send(new UpdateCommand(updateInProgressParams));

      let finalResults: AIAnalysisResults | null = null;
      let finalStatus: string = '';
      let errorDetails: string | null = null;

      try {
        // 3. Perform AI Analysis using data from SQS message
        console.log(`Performing AI analysis for ${analysisId} using text of length ${extractedText.length} for state: ${userSelectedState || 'general'}`);
        const { initialAnalysisResults, actionableInsightsData } = await performAiLeaseAnalysisInternal(
          extractedText,          // From SQS message
          userSelectedState,      // From SQS message
          openaiClient
        );
        finalResults = { ...initialAnalysisResults, ...actionableInsightsData };
        finalStatus = 'ANALYSIS_COMPLETE';
        console.log(`AI analysis successful for ${analysisId}`);

      } catch (aiError: any) {
        console.error(`Error during AI processing for ${analysisId}:`, aiError);
        finalStatus = 'AI_PROCESSING_FAILED';
        errorDetails = aiError.message || "Unknown AI processing error.";
        if (aiError.partialResults) {
            // If actionable insights failed, but initial analysis succeeded
            finalResults = { ...(aiError.partialResults as InitialAnalysisResults), actionableInsights: { overallRecommendation: "", nextSteps: []} };
            finalStatus = 'PARTIAL_ANALYSIS_INSIGHTS_FAILED';
            errorDetails = `Insights: ${errorDetails}`;
            console.log(`Partial results saved for ${analysisId} due to insights failure.`);
        }
      }

      // 4. Update DynamoDB with final results/status
      console.log(`Updating status to ${finalStatus} for ${analysisId}`);
      const updateFinalParams: any = {
        TableName: DYNAMODB_TABLE!,
        Key: { analysisId },
        UpdateExpression: "set #status = :status, #analysisResults = :analysisResults, #lastUpdatedTimestamp = :timestamp",
        ExpressionAttributeNames: {
          "#status": "status",
          "#analysisResults": "analysisResults",
          "#lastUpdatedTimestamp": "lastUpdatedTimestamp",
        },
        ExpressionAttributeValues: {
          ":status": finalStatus,
          ":analysisResults": finalResults, // Store the combined results
          ":timestamp": new Date().toISOString(),
        },
      };
      if (errorDetails) {
        updateFinalParams.UpdateExpression += ", #errorDetails = :errorDetails";
        updateFinalParams.ExpressionAttributeNames["#errorDetails"] = "errorDetails";
        updateFinalParams.ExpressionAttributeValues[":errorDetails"] = errorDetails;
      }
      await docClient.send(new UpdateCommand(updateFinalParams));
      console.log(`Successfully processed and updated ${analysisId}. Status: ${finalStatus}`);

    } catch (error: any) {
      console.error(`Failed to process SQS record for analysisId ${analysisId || 'unknown'}:`, error);
      // If analysisId is known and error is not during final DDB update, try to update DDB with error status
      if (analysisId) { 
        await updateDynamoDBOnError(analysisId, 'AI_PROCESSING_FAILED', error.message || 'Unknown error during SQS record processing');
      }
    }
  }
};

// Helper function to update DynamoDB on error, to avoid code duplication in catch blocks
async function updateDynamoDBOnError(analysisId: string, status: string, errorMessage: string) {
    console.log(`Updating DynamoDB for ${analysisId} with error status ${status} due to: ${errorMessage}`);
    try {
        const errorUpdateParams = {
            TableName: DYNAMODB_TABLE!,
            Key: { analysisId },
            UpdateExpression: "set #status = :status, #errorDetails = :errorDetails, #lastUpdatedTimestamp = :timestamp",
            ExpressionAttributeNames: { 
                "#status": "status", 
                "#errorDetails": "errorDetails",
                "#lastUpdatedTimestamp": "lastUpdatedTimestamp"
            },
            ExpressionAttributeValues: {
                ":status": status,
                ":errorDetails": errorMessage.substring(0, 2000), // Cap error message length
                ":timestamp": new Date().toISOString(),
            },
        };
        await docClient.send(new UpdateCommand(errorUpdateParams));
        console.log(`Successfully updated ${analysisId} with error status.`);
    } catch (dbError) {
        console.error(`Failed to update DynamoDB with error status for ${analysisId}:`, dbError);
        // Swallow this error as the main error is already logged.
    }
} 