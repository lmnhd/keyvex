"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptManager = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class PromptManager {
    constructor() {
        // Cache to avoid repeated API calls within the same Lambda execution
        this.promptCache = new Map();
        this.dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
        this.promptsTableName = process.env.PROMPTS_TABLE_NAME;
    }
    /**
     * Get active prompt configuration for lease analysis
     */
    async getLeaseAnalysisConfig() {
        try {
            // Get system prompt
            const systemPrompt = await this.getPrompt('lease-analysis-system', 'active');
            // Get user prompt template
            const userPromptTemplate = await this.getPrompt('lease-analysis-user', 'active');
            return {
                model: process.env.OPENAI_MODEL || 'gpt-4o',
                temperature: 0.1,
                maxTokens: 4000,
                systemPrompt,
                userPromptTemplate
            };
        }
        catch (error) {
            console.error('Failed to get prompt config, using defaults:', error);
            return this.getDefaultConfig();
        }
    }
    /**
     * Get a specific prompt by type and version
     */
    async getPrompt(promptType, version) {
        const cacheKey = `${promptType}:${version}`;
        if (this.promptCache.has(cacheKey)) {
            return this.promptCache.get(cacheKey);
        }
        try {
            // Get prompt from DynamoDB
            const metadata = await this.getPromptMetadata(promptType, version);
            this.promptCache.set(cacheKey, metadata.promptText);
            return metadata.promptText;
        }
        catch (error) {
            console.error(`Failed to get prompt ${promptType}:${version}:`, error);
            const defaultPrompt = this.getDefaultPrompt(promptType);
            this.promptCache.set(cacheKey, defaultPrompt);
            return defaultPrompt;
        }
    }
    /**
     * Get prompt metadata from DynamoDB
     */
    async getPromptMetadata(promptType, version) {
        const command = new client_dynamodb_1.GetItemCommand({
            TableName: this.promptsTableName,
            Key: {
                promptType: { S: promptType },
                version: { S: version }
            }
        });
        const result = await this.dynamoClient.send(command);
        if (!result.Item) {
            throw new Error(`Prompt metadata not found: ${promptType}:${version}`);
        }
        return {
            promptType: result.Item.promptType.S,
            version: result.Item.version.S,
            isActive: result.Item.isActive?.BOOL || false,
            promptText: result.Item.promptText?.S || '',
            createdAt: result.Item.createdAt?.S || '',
            updatedAt: result.Item.updatedAt?.S || ''
        };
    }
    /**
     * Fallback default configuration
     */
    getDefaultConfig() {
        return {
            model: 'gpt-4o',
            temperature: 0.1,
            maxTokens: 4000,
            systemPrompt: this.getDefaultPrompt('lease-analysis-system'),
            userPromptTemplate: this.getDefaultPrompt('lease-analysis-user')
        };
    }
    /**
     * Default prompts as fallback
     */
    getDefaultPrompt(promptType) {
        const defaults = {
            'lease-analysis-system': `You are a legal expert specializing in residential lease agreements. 
        Analyze the provided lease document and identify key terms, potential issues, and tenant rights.
        Provide clear, actionable insights for the tenant.`,
            'lease-analysis-user': `Please analyze this lease document text and provide:
        1. Key lease terms (rent, duration, deposits)
        2. Tenant rights and responsibilities
        3. Landlord obligations
        4. Potential red flags or concerning clauses
        5. Recommendations for the tenant
        
        Lease text: {leaseText}
        State: {userSelectedState}`
        };
        return defaults[promptType] || 'Default prompt not available.';
    }
    /**
     * Format user prompt with variables
     */
    formatUserPrompt(template, variables) {
        let formatted = template;
        Object.entries(variables).forEach(([key, value]) => {
            const placeholder = `{${key}}`;
            formatted = formatted.replace(new RegExp(placeholder, 'g'), value);
        });
        return formatted;
    }
}
exports.PromptManager = PromptManager;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LW1hbmFnZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwcm9tcHQtbWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw4REFBMEU7QUFtQjFFLE1BQWEsYUFBYTtJQU94QjtRQUhBLHFFQUFxRTtRQUM3RCxnQkFBVyxHQUF3QixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBR25ELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxnQ0FBYyxDQUFDLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDMUYsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQW1CLENBQUM7SUFDMUQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHNCQUFzQjtRQUMxQixJQUFJLENBQUM7WUFDSCxvQkFBb0I7WUFDcEIsTUFBTSxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRTdFLDJCQUEyQjtZQUMzQixNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVqRixPQUFPO2dCQUNMLEtBQUssRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksSUFBSSxRQUFRO2dCQUMzQyxXQUFXLEVBQUUsR0FBRztnQkFDaEIsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsWUFBWTtnQkFDWixrQkFBa0I7YUFDbkIsQ0FBQztRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw4Q0FBOEMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNyRSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQWtCLEVBQUUsT0FBZTtRQUN6RCxNQUFNLFFBQVEsR0FBRyxHQUFHLFVBQVUsSUFBSSxPQUFPLEVBQUUsQ0FBQztRQUU1QyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7WUFDbkMsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUUsQ0FBQztRQUN6QyxDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsMkJBQTJCO1lBQzNCLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUVuRSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3BELE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQztRQUU3QixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLFVBQVUsSUFBSSxPQUFPLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN2RSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzlDLE9BQU8sYUFBYSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsaUJBQWlCLENBQUMsVUFBa0IsRUFBRSxPQUFlO1FBQ2pFLE1BQU0sT0FBTyxHQUFHLElBQUksZ0NBQWMsQ0FBQztZQUNqQyxTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtZQUNoQyxHQUFHLEVBQUU7Z0JBQ0gsVUFBVSxFQUFFLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRTtnQkFDN0IsT0FBTyxFQUFFLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRTthQUN4QjtTQUNGLENBQUMsQ0FBQztRQUVILE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFckQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLDhCQUE4QixVQUFVLElBQUksT0FBTyxFQUFFLENBQUMsQ0FBQztRQUN6RSxDQUFDO1FBRUQsT0FBTztZQUNMLFVBQVUsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFFO1lBQ3JDLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFFO1lBQy9CLFFBQVEsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLElBQUksS0FBSztZQUM3QyxVQUFVLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLEVBQUU7WUFDM0MsU0FBUyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFO1lBQ3pDLFNBQVMsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRTtTQUMxQyxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ssZ0JBQWdCO1FBQ3RCLE9BQU87WUFDTCxLQUFLLEVBQUUsUUFBUTtZQUNmLFdBQVcsRUFBRSxHQUFHO1lBQ2hCLFNBQVMsRUFBRSxJQUFJO1lBQ2YsWUFBWSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztZQUM1RCxrQkFBa0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLENBQUM7U0FDakUsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNLLGdCQUFnQixDQUFDLFVBQWtCO1FBQ3pDLE1BQU0sUUFBUSxHQUEyQjtZQUN2Qyx1QkFBdUIsRUFBRTs7MkRBRTRCO1lBRXJELHFCQUFxQixFQUFFOzs7Ozs7OzttQ0FRTTtTQUM5QixDQUFDO1FBRUYsT0FBTyxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksK0JBQStCLENBQUM7SUFDakUsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZ0JBQWdCLENBQUMsUUFBZ0IsRUFBRSxTQUFpQztRQUNsRSxJQUFJLFNBQVMsR0FBRyxRQUFRLENBQUM7UUFFekIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFO1lBQ2pELE1BQU0sV0FBVyxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7WUFDL0IsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztDQUNGO0FBMUlELHNDQTBJQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IER5bmFtb0RCQ2xpZW50LCBHZXRJdGVtQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYic7XHJcblxyXG5pbnRlcmZhY2UgUHJvbXB0Q29uZmlnIHtcclxuICBtb2RlbDogc3RyaW5nO1xyXG4gIHRlbXBlcmF0dXJlOiBudW1iZXI7XHJcbiAgbWF4VG9rZW5zOiBudW1iZXI7XHJcbiAgc3lzdGVtUHJvbXB0OiBzdHJpbmc7XHJcbiAgdXNlclByb21wdFRlbXBsYXRlOiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBQcm9tcHRNZXRhZGF0YSB7XHJcbiAgcHJvbXB0VHlwZTogc3RyaW5nO1xyXG4gIHZlcnNpb246IHN0cmluZztcclxuICBpc0FjdGl2ZTogYm9vbGVhbjtcclxuICBwcm9tcHRUZXh0OiBzdHJpbmc7XHJcbiAgY3JlYXRlZEF0OiBzdHJpbmc7XHJcbiAgdXBkYXRlZEF0OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQcm9tcHRNYW5hZ2VyIHtcclxuICBwcml2YXRlIGR5bmFtb0NsaWVudDogRHluYW1vREJDbGllbnQ7XHJcbiAgcHJpdmF0ZSBwcm9tcHRzVGFibGVOYW1lOiBzdHJpbmc7XHJcbiAgXHJcbiAgLy8gQ2FjaGUgdG8gYXZvaWQgcmVwZWF0ZWQgQVBJIGNhbGxzIHdpdGhpbiB0aGUgc2FtZSBMYW1iZGEgZXhlY3V0aW9uXHJcbiAgcHJpdmF0ZSBwcm9tcHRDYWNoZTogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXAoKTtcclxuICBcclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMuZHluYW1vQ2xpZW50ID0gbmV3IER5bmFtb0RCQ2xpZW50KHsgcmVnaW9uOiBwcm9jZXNzLmVudi5BV1NfUkVHSU9OIHx8ICd1cy1lYXN0LTEnIH0pO1xyXG4gICAgdGhpcy5wcm9tcHRzVGFibGVOYW1lID0gcHJvY2Vzcy5lbnYuUFJPTVBUU19UQUJMRV9OQU1FITtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldCBhY3RpdmUgcHJvbXB0IGNvbmZpZ3VyYXRpb24gZm9yIGxlYXNlIGFuYWx5c2lzXHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0TGVhc2VBbmFseXNpc0NvbmZpZygpOiBQcm9taXNlPFByb21wdENvbmZpZz4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gR2V0IHN5c3RlbSBwcm9tcHRcclxuICAgICAgY29uc3Qgc3lzdGVtUHJvbXB0ID0gYXdhaXQgdGhpcy5nZXRQcm9tcHQoJ2xlYXNlLWFuYWx5c2lzLXN5c3RlbScsICdhY3RpdmUnKTtcclxuICAgICAgXHJcbiAgICAgIC8vIEdldCB1c2VyIHByb21wdCB0ZW1wbGF0ZVxyXG4gICAgICBjb25zdCB1c2VyUHJvbXB0VGVtcGxhdGUgPSBhd2FpdCB0aGlzLmdldFByb21wdCgnbGVhc2UtYW5hbHlzaXMtdXNlcicsICdhY3RpdmUnKTtcclxuICAgICAgXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgbW9kZWw6IHByb2Nlc3MuZW52Lk9QRU5BSV9NT0RFTCB8fCAnZ3B0LTRvJyxcclxuICAgICAgICB0ZW1wZXJhdHVyZTogMC4xLFxyXG4gICAgICAgIG1heFRva2VuczogNDAwMCxcclxuICAgICAgICBzeXN0ZW1Qcm9tcHQsXHJcbiAgICAgICAgdXNlclByb21wdFRlbXBsYXRlXHJcbiAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gZ2V0IHByb21wdCBjb25maWcsIHVzaW5nIGRlZmF1bHRzOicsIGVycm9yKTtcclxuICAgICAgcmV0dXJuIHRoaXMuZ2V0RGVmYXVsdENvbmZpZygpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2V0IGEgc3BlY2lmaWMgcHJvbXB0IGJ5IHR5cGUgYW5kIHZlcnNpb25cclxuICAgKi9cclxuICBwcml2YXRlIGFzeW5jIGdldFByb21wdChwcm9tcHRUeXBlOiBzdHJpbmcsIHZlcnNpb246IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCBjYWNoZUtleSA9IGAke3Byb21wdFR5cGV9OiR7dmVyc2lvbn1gO1xyXG4gICAgXHJcbiAgICBpZiAodGhpcy5wcm9tcHRDYWNoZS5oYXMoY2FjaGVLZXkpKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLnByb21wdENhY2hlLmdldChjYWNoZUtleSkhO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIEdldCBwcm9tcHQgZnJvbSBEeW5hbW9EQlxyXG4gICAgICBjb25zdCBtZXRhZGF0YSA9IGF3YWl0IHRoaXMuZ2V0UHJvbXB0TWV0YWRhdGEocHJvbXB0VHlwZSwgdmVyc2lvbik7XHJcbiAgICAgIFxyXG4gICAgICB0aGlzLnByb21wdENhY2hlLnNldChjYWNoZUtleSwgbWV0YWRhdGEucHJvbXB0VGV4dCk7XHJcbiAgICAgIHJldHVybiBtZXRhZGF0YS5wcm9tcHRUZXh0O1xyXG4gICAgICBcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBnZXQgcHJvbXB0ICR7cHJvbXB0VHlwZX06JHt2ZXJzaW9ufTpgLCBlcnJvcik7XHJcbiAgICAgIGNvbnN0IGRlZmF1bHRQcm9tcHQgPSB0aGlzLmdldERlZmF1bHRQcm9tcHQocHJvbXB0VHlwZSk7XHJcbiAgICAgIHRoaXMucHJvbXB0Q2FjaGUuc2V0KGNhY2hlS2V5LCBkZWZhdWx0UHJvbXB0KTtcclxuICAgICAgcmV0dXJuIGRlZmF1bHRQcm9tcHQ7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXQgcHJvbXB0IG1ldGFkYXRhIGZyb20gRHluYW1vREJcclxuICAgKi9cclxuICBwcml2YXRlIGFzeW5jIGdldFByb21wdE1ldGFkYXRhKHByb21wdFR5cGU6IHN0cmluZywgdmVyc2lvbjogc3RyaW5nKTogUHJvbWlzZTxQcm9tcHRNZXRhZGF0YT4ge1xyXG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBHZXRJdGVtQ29tbWFuZCh7XHJcbiAgICAgIFRhYmxlTmFtZTogdGhpcy5wcm9tcHRzVGFibGVOYW1lLFxyXG4gICAgICBLZXk6IHtcclxuICAgICAgICBwcm9tcHRUeXBlOiB7IFM6IHByb21wdFR5cGUgfSxcclxuICAgICAgICB2ZXJzaW9uOiB7IFM6IHZlcnNpb24gfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmR5bmFtb0NsaWVudC5zZW5kKGNvbW1hbmQpO1xyXG4gICAgXHJcbiAgICBpZiAoIXJlc3VsdC5JdGVtKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihgUHJvbXB0IG1ldGFkYXRhIG5vdCBmb3VuZDogJHtwcm9tcHRUeXBlfToke3ZlcnNpb259YCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcHJvbXB0VHlwZTogcmVzdWx0Lkl0ZW0ucHJvbXB0VHlwZS5TISxcclxuICAgICAgdmVyc2lvbjogcmVzdWx0Lkl0ZW0udmVyc2lvbi5TISxcclxuICAgICAgaXNBY3RpdmU6IHJlc3VsdC5JdGVtLmlzQWN0aXZlPy5CT09MIHx8IGZhbHNlLFxyXG4gICAgICBwcm9tcHRUZXh0OiByZXN1bHQuSXRlbS5wcm9tcHRUZXh0Py5TIHx8ICcnLFxyXG4gICAgICBjcmVhdGVkQXQ6IHJlc3VsdC5JdGVtLmNyZWF0ZWRBdD8uUyB8fCAnJyxcclxuICAgICAgdXBkYXRlZEF0OiByZXN1bHQuSXRlbS51cGRhdGVkQXQ/LlMgfHwgJydcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBGYWxsYmFjayBkZWZhdWx0IGNvbmZpZ3VyYXRpb25cclxuICAgKi9cclxuICBwcml2YXRlIGdldERlZmF1bHRDb25maWcoKTogUHJvbXB0Q29uZmlnIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIG1vZGVsOiAnZ3B0LTRvJyxcclxuICAgICAgdGVtcGVyYXR1cmU6IDAuMSxcclxuICAgICAgbWF4VG9rZW5zOiA0MDAwLFxyXG4gICAgICBzeXN0ZW1Qcm9tcHQ6IHRoaXMuZ2V0RGVmYXVsdFByb21wdCgnbGVhc2UtYW5hbHlzaXMtc3lzdGVtJyksXHJcbiAgICAgIHVzZXJQcm9tcHRUZW1wbGF0ZTogdGhpcy5nZXREZWZhdWx0UHJvbXB0KCdsZWFzZS1hbmFseXNpcy11c2VyJylcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBEZWZhdWx0IHByb21wdHMgYXMgZmFsbGJhY2tcclxuICAgKi9cclxuICBwcml2YXRlIGdldERlZmF1bHRQcm9tcHQocHJvbXB0VHlwZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGRlZmF1bHRzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gICAgICAnbGVhc2UtYW5hbHlzaXMtc3lzdGVtJzogYFlvdSBhcmUgYSBsZWdhbCBleHBlcnQgc3BlY2lhbGl6aW5nIGluIHJlc2lkZW50aWFsIGxlYXNlIGFncmVlbWVudHMuIFxyXG4gICAgICAgIEFuYWx5emUgdGhlIHByb3ZpZGVkIGxlYXNlIGRvY3VtZW50IGFuZCBpZGVudGlmeSBrZXkgdGVybXMsIHBvdGVudGlhbCBpc3N1ZXMsIGFuZCB0ZW5hbnQgcmlnaHRzLlxyXG4gICAgICAgIFByb3ZpZGUgY2xlYXIsIGFjdGlvbmFibGUgaW5zaWdodHMgZm9yIHRoZSB0ZW5hbnQuYCxcclxuICAgICAgXHJcbiAgICAgICdsZWFzZS1hbmFseXNpcy11c2VyJzogYFBsZWFzZSBhbmFseXplIHRoaXMgbGVhc2UgZG9jdW1lbnQgdGV4dCBhbmQgcHJvdmlkZTpcclxuICAgICAgICAxLiBLZXkgbGVhc2UgdGVybXMgKHJlbnQsIGR1cmF0aW9uLCBkZXBvc2l0cylcclxuICAgICAgICAyLiBUZW5hbnQgcmlnaHRzIGFuZCByZXNwb25zaWJpbGl0aWVzXHJcbiAgICAgICAgMy4gTGFuZGxvcmQgb2JsaWdhdGlvbnNcclxuICAgICAgICA0LiBQb3RlbnRpYWwgcmVkIGZsYWdzIG9yIGNvbmNlcm5pbmcgY2xhdXNlc1xyXG4gICAgICAgIDUuIFJlY29tbWVuZGF0aW9ucyBmb3IgdGhlIHRlbmFudFxyXG4gICAgICAgIFxyXG4gICAgICAgIExlYXNlIHRleHQ6IHtsZWFzZVRleHR9XHJcbiAgICAgICAgU3RhdGU6IHt1c2VyU2VsZWN0ZWRTdGF0ZX1gXHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiBkZWZhdWx0c1twcm9tcHRUeXBlXSB8fCAnRGVmYXVsdCBwcm9tcHQgbm90IGF2YWlsYWJsZS4nO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRm9ybWF0IHVzZXIgcHJvbXB0IHdpdGggdmFyaWFibGVzXHJcbiAgICovXHJcbiAgZm9ybWF0VXNlclByb21wdCh0ZW1wbGF0ZTogc3RyaW5nLCB2YXJpYWJsZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4pOiBzdHJpbmcge1xyXG4gICAgbGV0IGZvcm1hdHRlZCA9IHRlbXBsYXRlO1xyXG4gICAgXHJcbiAgICBPYmplY3QuZW50cmllcyh2YXJpYWJsZXMpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xyXG4gICAgICBjb25zdCBwbGFjZWhvbGRlciA9IGB7JHtrZXl9fWA7XHJcbiAgICAgIGZvcm1hdHRlZCA9IGZvcm1hdHRlZC5yZXBsYWNlKG5ldyBSZWdFeHAocGxhY2Vob2xkZXIsICdnJyksIHZhbHVlKTtcclxuICAgIH0pO1xyXG4gICAgXHJcbiAgICByZXR1cm4gZm9ybWF0dGVkO1xyXG4gIH1cclxufSAiXX0=