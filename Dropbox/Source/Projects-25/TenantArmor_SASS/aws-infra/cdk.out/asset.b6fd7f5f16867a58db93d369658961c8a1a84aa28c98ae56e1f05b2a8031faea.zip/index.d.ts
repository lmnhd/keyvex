export interface Issue {
    description: string;
    severity: "High" | "Medium" | "Low";
    recommendation: string;
}
export interface Clause {
    title: string;
    text: string;
    issues: Issue[];
}
export interface InitialAnalysisResults {
    summary: string;
    overallSeverity: "High" | "Medium" | "Low";
    clauses: Clause[];
}
export interface NextStep {
    step: string;
    importance: "High" | "Medium" | "Consider";
    details?: string;
}
export interface ActionableInsightsData {
    actionableInsights: {
        overallRecommendation: string;
        nextSteps: NextStep[];
    };
}
export interface AIAnalysisResults extends InitialAnalysisResults, ActionableInsightsData {
}
export declare const handler: (event: any, context: any) => Promise<void>;
